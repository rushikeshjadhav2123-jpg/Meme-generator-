export interface MemeTemplate {
  id: string;
  name: string;
  url: string;
  defaultTop: string;
  defaultBottom: string;
}

export interface CaptionAlternative {
  top: string;
  bottom: string;
}

export interface MemeRecord {
  id: string;
  title: string;
  prompt?: string;
  top_text: string;
  bottom_text: string;
  image_url: string;
  font_family?: string;
  text_size?: number;
  text_color?: string;
  stroke_color?: string;
  upvotes?: number;
  created_at: number;
}

export interface DatabaseStats {
  connected: boolean;
  databaseFile: string;
  engine: string;
  totalMemes: number;
  totalUpvotes: number;
  promptsAnalyzed: number;
  fileSizeBytes: number;
}

export interface MemeState {
  imageSrc: string | null;
  imageElement: HTMLImageElement | null;
  imagePrompt: string;
  captionTopic: string;
  topText: string;
  bottomText: string;
  textSize: number;
  textColor: string;
  strokeColor: string;
  fontFamily: string;
  isUppercase: boolean;
  statusText: string;
  isGeneratingImage: boolean;
  isGeneratingCaption: boolean;
  isAnalyzingPrompt: boolean;
  aiAnalysis: string | null;
  aiModelUsed: string | null;
  suggestedTemplate?: MemeTemplate | null;
  relatedTemplates?: MemeTemplate[];
  imageStyle?: "photo" | "comic" | "3d" | "svg";
  captionAlternatives: CaptionAlternative[];
  imageError: string | null;
  captionError: string | null;
}
