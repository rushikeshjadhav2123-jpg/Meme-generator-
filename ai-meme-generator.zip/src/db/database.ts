import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";

export interface MemeRecord {
  id: string;
  title: string;
  prompt?: string;
  top_text: string;
  bottom_text: string;
  image_url: string;
  font_family?: string;
  text_size?: number;
  text_color?: string;
  stroke_color?: string;
  upvotes?: number;
  created_at: number;
}

export interface PromptHistoryRecord {
  id: string;
  prompt: string;
  analysis: string;
  model_used: string;
  created_at: number;
}

const DATA_DIR = path.join(process.cwd(), "data");
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_FILE = path.join(DATA_DIR, "memes.db");
const db = new DatabaseSync(DB_FILE);

// Initialize relational SQLite schema
db.exec(`
  PRAGMA journal_mode = WAL;

  CREATE TABLE IF NOT EXISTS memes (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    prompt TEXT,
    top_text TEXT NOT NULL,
    bottom_text TEXT NOT NULL,
    image_url TEXT NOT NULL,
    font_family TEXT DEFAULT 'Impact',
    text_size INTEGER DEFAULT 48,
    text_color TEXT DEFAULT '#ffffff',
    stroke_color TEXT DEFAULT '#000000',
    upvotes INTEGER DEFAULT 0,
    created_at INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_memes_created ON memes(created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_memes_upvotes ON memes(upvotes DESC);

  CREATE TABLE IF NOT EXISTS prompt_history (
    id TEXT PRIMARY KEY,
    prompt TEXT NOT NULL,
    analysis TEXT,
    model_used TEXT,
    created_at INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_prompts_created ON prompt_history(created_at DESC);
`);

// Seed default memes if database is freshly created
const existingCountRow: any = db.prepare("SELECT COUNT(*) as count FROM memes").get();
if (existingCountRow && existingCountRow.count === 0) {
  const seedMemes: MemeRecord[] = [
    {
      id: "seed-1",
      title: "Weekend Call Dilemma",
      prompt: "my boss called me on weekend",
      top_text: "WHEN YOUR BOSS CALLS YOU",
      bottom_text: "ON A SUNDAY AFTERNOON",
      image_url: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80",
      font_family: "Impact",
      text_size: 48,
      text_color: "#ffffff",
      stroke_color: "#000000",
      upvotes: 42,
      created_at: Date.now() - 3600000 * 24,
    },
    {
      id: "seed-2",
      title: "Friday Production Release",
      prompt: "deploying to production on Friday 5pm",
      top_text: "PRODUCTION SERVER IS DOWN",
      bottom_text: "THIS IS COMPLETELY FINE",
      image_url: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=800&q=80",
      font_family: "Impact",
      text_size: 44,
      text_color: "#ffffff",
      stroke_color: "#000000",
      upvotes: 89,
      created_at: Date.now() - 3600000 * 12,
    },
    {
      id: "seed-3",
      title: "Hard Choices",
      prompt: "choosing between answering boss and pretending phone died",
      top_text: "ANSWER THE WORK CALL",
      bottom_text: "PRETEND MY BATTERY DIED",
      image_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80",
      font_family: "Impact",
      text_size: 46,
      text_color: "#ffffff",
      stroke_color: "#000000",
      upvotes: 65,
      created_at: Date.now() - 3600000 * 6,
    },
    {
      id: "seed-4",
      title: "Distracted Developer",
      prompt: "relaxing vs urgent bug",
      top_text: "ME TRYING TO RELAX",
      bottom_text: "URGENT MONDAY DEADLINE",
      image_url: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80",
      font_family: "Impact",
      text_size: 48,
      text_color: "#ffffff",
      stroke_color: "#000000",
      upvotes: 112,
      created_at: Date.now() - 3600000 * 2,
    },
  ];

  const insertStmt = db.prepare(`
    INSERT INTO memes (id, title, prompt, top_text, bottom_text, image_url, font_family, text_size, text_color, stroke_color, upvotes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  for (const m of seedMemes) {
    insertStmt.run(
      m.id,
      m.title,
      m.prompt || null,
      m.top_text,
      m.bottom_text,
      m.image_url,
      m.font_family || "Impact",
      m.text_size || 48,
      m.text_color || "#ffffff",
      m.stroke_color || "#000000",
      m.upvotes || 0,
      m.created_at
    );
  }
}

export const dbService = {
  // Query all memes with optional search and sorting
  getMemes(search?: string, sortBy: "latest" | "popular" = "latest"): MemeRecord[] {
    let sql = "SELECT * FROM memes";
    const params: any[] = [];

    if (search && search.trim()) {
      sql += " WHERE title LIKE ? OR top_text LIKE ? OR bottom_text LIKE ? OR prompt LIKE ?";
      const term = `%${search.trim()}%`;
      params.push(term, term, term, term);
    }

    if (sortBy === "popular") {
      sql += " ORDER BY upvotes DESC, created_at DESC";
    } else {
      sql += " ORDER BY created_at DESC";
    }

    const stmt = db.prepare(sql);
    return stmt.all(...params) as unknown as MemeRecord[];
  },

  getMemeById(id: string): MemeRecord | null {
    const stmt = db.prepare("SELECT * FROM memes WHERE id = ?");
    const row = stmt.get(id);
    return (row as unknown as MemeRecord) || null;
  },

  saveMeme(meme: Omit<MemeRecord, "id" | "created_at" | "upvotes"> & { id?: string }): MemeRecord {
    const id = meme.id || `meme-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const created_at = Date.now();
    const upvotes = 0;

    const stmt = db.prepare(`
      INSERT INTO memes (id, title, prompt, top_text, bottom_text, image_url, font_family, text_size, text_color, stroke_color, upvotes, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      id,
      meme.title || meme.top_text || "Untitled Meme",
      meme.prompt || null,
      meme.top_text,
      meme.bottom_text,
      meme.image_url,
      meme.font_family || "Impact",
      meme.text_size || 48,
      meme.text_color || "#ffffff",
      meme.stroke_color || "#000000",
      upvotes,
      created_at
    );

    return {
      id,
      title: meme.title || meme.top_text || "Untitled Meme",
      prompt: meme.prompt,
      top_text: meme.top_text,
      bottom_text: meme.bottom_text,
      image_url: meme.image_url,
      font_family: meme.font_family,
      text_size: meme.text_size,
      text_color: meme.text_color,
      stroke_color: meme.stroke_color,
      upvotes,
      created_at,
    };
  },

  upvoteMeme(id: string): { upvotes: number } | null {
    const updateStmt = db.prepare("UPDATE memes SET upvotes = upvotes + 1 WHERE id = ?");
    updateStmt.run(id);

    const getStmt = db.prepare("SELECT upvotes FROM memes WHERE id = ?");
    const row: any = getStmt.get(id);
    return row ? { upvotes: row.upvotes } : null;
  },

  deleteMeme(id: string): boolean {
    const stmt = db.prepare("DELETE FROM memes WHERE id = ?");
    const result: any = stmt.run(id);
    return result.changes > 0;
  },

  logPromptAnalysis(prompt: string, analysis: string, model_used: string) {
    const id = `prompt-${Date.now()}`;
    const stmt = db.prepare(`
      INSERT INTO prompt_history (id, prompt, analysis, model_used, created_at)
      VALUES (?, ?, ?, ?, ?)
    `);
    stmt.run(id, prompt, analysis, model_used, Date.now());
  },

  getStats() {
    const memesCountRow: any = db.prepare("SELECT COUNT(*) as count FROM memes").get();
    const upvotesRow: any = db.prepare("SELECT SUM(upvotes) as sum FROM memes").get();
    const promptCountRow: any = db.prepare("SELECT COUNT(*) as count FROM prompt_history").get();

    let fileSize = 0;
    try {
      fileSize = fs.statSync(DB_FILE).size;
    } catch {}

    return {
      connected: true,
      databaseFile: "data/memes.db",
      engine: "SQLite 3 (Embedded Relational DB)",
      totalMemes: memesCountRow?.count || 0,
      totalUpvotes: upvotesRow?.sum || 0,
      promptsAnalyzed: promptCountRow?.count || 0,
      fileSizeBytes: fileSize,
    };
  },
};
