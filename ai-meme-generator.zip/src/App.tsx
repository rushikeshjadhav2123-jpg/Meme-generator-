import React, { useState, useEffect } from "react";
import { ControlsPanel } from "./components/ControlsPanel";
import { MemeCanvas } from "./components/MemeCanvas";
import { DatabaseGallery } from "./components/DatabaseGallery";
import { MemeState, MemeTemplate, MemeRecord } from "./types";
import { downloadProjectZip } from "./utils/zipExport";
import { FolderDown, Sparkles, AlertCircle, CheckCircle2, Database } from "lucide-react";

export default function App() {
  const [templates, setTemplates] = useState<MemeTemplate[]>([]);
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [zipSuccess, setZipSuccess] = useState(false);
  const [refreshDbTrigger, setRefreshDbTrigger] = useState(0);
  const [isSavingToDb, setIsSavingToDb] = useState(false);
  const [dbSaveSuccess, setDbSaveSuccess] = useState(false);

  const [state, setState] = useState<MemeState>({
    imageSrc: null,
    imageElement: null,
    imagePrompt: "",
    captionTopic: "",
    topText: "",
    bottomText: "",
    textSize: 48,
    textColor: "#ffffff",
    strokeColor: "#000000",
    fontFamily: "Impact",
    isUppercase: true,
    statusText: "Ready to create",
    isGeneratingImage: false,
    isGeneratingCaption: false,
    isAnalyzingPrompt: false,
    aiAnalysis: null,
    aiModelUsed: null,
    captionAlternatives: [],
    imageError: null,
    captionError: null,
  });

  // Fetch initial templates on load
  useEffect(() => {
    fetch("/api/templates")
      .then((res) => res.json())
      .then((data) => {
        if (data.templates && data.templates.length > 0) {
          setTemplates(data.templates);
          // Pre-load the first iconic meme template if nothing is loaded yet
          if (!state.imageSrc) {
            const first = data.templates[0];
            loadImageElement(first.url, () => {
              updateState({
                imageSrc: first.url,
                topText: first.defaultTop,
                bottomText: first.defaultBottom,
                captionTopic: first.name,
                imagePrompt: first.name,
                suggestedTemplate: first,
                statusText: "Ready! Loaded classic meme ✨",
              });
            });
          }
        }
      })
      .catch((err) => console.warn("Failed to load meme templates:", err));
  }, []);

  const updateState = (updates: Partial<MemeState>) => {
    setState((prev) => ({ ...prev, ...updates }));
  };

  // Helper to load an image URL into an HTMLImageElement with CORS fallback
  const loadImageElement = (url: string, callback?: (img: HTMLImageElement) => void) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      updateState({
        imageSrc: url,
        imageElement: img,
        imageError: null,
        statusText: "Image ready ✨ Ready for captions",
      });
      if (callback) callback(img);
    };
    img.onerror = () => {
      // If anonymous CORS failed, retry without crossOrigin
      if (img.crossOrigin) {
        const retryImg = new Image();
        retryImg.onload = () => {
          updateState({
            imageSrc: url,
            imageElement: retryImg,
            imageError: null,
            statusText: "Image ready ✨",
          });
          if (callback) callback(retryImg);
        };
        retryImg.onerror = () => {
          updateState({
            imageError: "The image could not be displayed. Please try another prompt or template.",
            statusText: "Image load failed",
            isGeneratingImage: false,
          });
        };
        retryImg.src = url;
        return;
      }
      updateState({
        imageError: "The generated image failed to load. Please try another prompt.",
        statusText: "Image load failed",
        isGeneratingImage: false,
      });
    };
    img.src = url;
  };

  // 1. Generate Image with AI with customizable style and variation seed
  const handleGenerateImage = async (
    overridePrompt?: string,
    overrideStyle?: "photo" | "comic" | "3d" | "svg"
  ) => {
    const prompt = (overridePrompt?.trim()) || (state.imagePrompt.trim()) || (state.captionTopic.trim());
    if (!prompt) {
      updateState({
        imageError: 'Describe a scene or prompt first (e.g. "a stressed worker getting a call on weekend").',
      });
      return;
    }

    const style = overrideStyle || state.imageStyle || "photo";
    const seed = Math.floor(Math.random() * 9999999);

    updateState({
      imagePrompt: prompt,
      imageStyle: style,
      isGeneratingImage: true,
      imageError: null,
      statusText: `Generating ${style} meme image with AI...`,
    });

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, style, seed }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to generate image.");
      }

      loadImageElement(data.image, () => {
        updateState({
          isGeneratingImage: false,
          suggestedTemplate: data.matchedTemplate || state.suggestedTemplate,
          relatedTemplates: data.relatedTemplates || state.relatedTemplates,
          statusText: "Meme image ready ✨ Customize text below",
        });
      });
    } catch (error: unknown) {
      console.error("Image generation error:", error);
      const msg = error instanceof Error ? error.message : "Couldn't generate an image. Try again.";
      updateState({
        isGeneratingImage: false,
        imageError: msg,
        statusText: "Image generation failed",
      });
    }
  };

  // 1b. Load direct Image from URL (Google Images, Imgur, Reddit, etc.)
  const handleLoadImageUrl = (url: string) => {
    if (!url || !url.trim()) return;
    const clean = url.trim();
    updateState({ isGeneratingImage: true, imageError: null, statusText: "Loading image from URL..." });
    loadImageElement(clean, () => {
      updateState({
        isGeneratingImage: false,
        imageSrc: clean,
        statusText: "Custom image loaded ✨",
      });
    });
  };

  // 2. Generate Captions with AI
  const handleGenerateCaption = async () => {
    const topic = (state.captionTopic.trim()) || (state.imagePrompt.trim());
    if (!topic) {
      updateState({
        captionError: 'Type a joke idea or prompt first (e.g. "my boss called on weekend").',
      });
      return;
    }

    updateState({
      captionTopic: topic,
      isGeneratingCaption: true,
      captionError: null,
      statusText: `AI analyzing joke topic: "${topic}"...`,
    });

    try {
      const response = await fetch("/api/generate-caption", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          sceneDescription: state.imagePrompt.trim(),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to generate captions.");
      }

      updateState({
        topText: data.top || "",
        bottomText: data.bottom || "",
        captionAlternatives: data.alternatives || [],
        aiAnalysis: data.analysis || null,
        aiModelUsed: data.provider || "gemini",
        isGeneratingCaption: false,
        statusText: "AI captions ready ✨",
      });
    } catch (error: unknown) {
      console.error("Caption generation error:", error);
      const msg = error instanceof Error ? error.message : "Couldn't generate captions. Try again.";
      updateState({
        isGeneratingCaption: false,
        captionError: msg,
        statusText: "Caption generation failed",
      });
    }
  };

  // 3. One-Click AI Prompt Analyzer: Analyzes user prompt, generates humor breakdown, captions & custom visual scene
  const handleAnalyzePrompt = async (customPrompt?: string) => {
    const raw = customPrompt !== undefined ? customPrompt : (state.captionTopic || state.imagePrompt);
    const prompt = raw.trim();

    if (!prompt) {
      updateState({
        captionError: 'Enter a prompt, joke, or situation first to analyze (e.g. "my boss called me on weekend").',
      });
      return;
    }

    updateState({
      isAnalyzingPrompt: true,
      captionError: null,
      imageError: null,
      statusText: `Gemini AI analyzing: "${prompt}"...`,
    });

    try {
      const response = await fetch("/api/analyze-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to analyze prompt.");
      }

      updateState({
        topText: data.top || "",
        bottomText: data.bottom || "",
        captionAlternatives: data.alternatives || [],
        aiAnalysis: data.analysis || null,
        aiModelUsed: data.model || "gemini",
        captionTopic: prompt,
        imagePrompt: data.visualScene || prompt,
        suggestedTemplate: data.suggestedTemplate || null,
        relatedTemplates: data.relatedTemplates || [],
        isAnalyzingPrompt: false,
      });

      // Immediately display the matched iconic meme template
      if (data.suggestedTemplate && data.suggestedTemplate.url) {
        loadImageElement(data.suggestedTemplate.url, () => {
          updateState({
            statusText: `Matched iconic meme: ${data.suggestedTemplate.name} ✨ Captions ready!`,
          });
        });
      } else if (data.visualScene) {
        // Otherwise generate custom vector scene
        updateState({ isGeneratingImage: true });
        try {
          const imgRes = await fetch("/api/generate-image", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt: data.visualScene }),
          });
          const imgData = await imgRes.json();
          if (imgRes.ok && imgData.image) {
            loadImageElement(imgData.image, () => {
              updateState({
                isGeneratingImage: false,
                statusText: "Meme ready! AI generated custom illustration + captions ✨",
              });
            });
          } else {
            updateState({ isGeneratingImage: false });
          }
        } catch (imgErr) {
          console.log("[Info] Scene image fallback:", imgErr);
          updateState({ isGeneratingImage: false });
        }
      }
    } catch (error: unknown) {
      console.error("Prompt analysis error:", error);
      const msg = error instanceof Error ? error.message : "Couldn't analyze prompt. Try again.";
      updateState({
        isAnalyzingPrompt: false,
        captionError: msg,
        statusText: "Analysis failed",
      });
    }
  };

  // Select a preset template
  const handleSelectTemplate = (template: MemeTemplate) => {
    loadImageElement(template.url, () => {
      updateState({
        topText: state.topText || template.defaultTop,
        bottomText: state.bottomText || template.defaultBottom,
        statusText: `Loaded ${template.name}`,
      });
    });
  };

  // Custom user image upload
  const handleUploadImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        loadImageElement(result, () => {
          updateState({
            statusText: "Custom image loaded ✨",
          });
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Reset all fields
  const handleReset = () => {
    updateState({
      imageSrc: null,
      imageElement: null,
      imagePrompt: "",
      captionTopic: "",
      topText: "",
      bottomText: "",
      textSize: 48,
      textColor: "#ffffff",
      strokeColor: "#000000",
      captionAlternatives: [],
      imageError: null,
      captionError: null,
      statusText: "Ready to create",
    });
  };

  // Export Project ZIP
  const handleExportZip = async () => {
    try {
      setIsExportingZip(true);
      await downloadProjectZip();
      setZipSuccess(true);
      setTimeout(() => setZipSuccess(false), 3000);
    } catch (e) {
      console.error("ZIP export failed:", e);
    } finally {
      setIsExportingZip(false);
    }
  };

  // Download Trigger from controls
  const handleDownload = () => {
    const btn = document.getElementById("downloadButton");
    if (btn) btn.click();
  };

  // Save current meme to SQLite database
  const handleSaveToDatabase = async () => {
    if (!state.imageSrc || (!state.topText && !state.bottomText)) {
      updateState({
        imageError: "Need both an image and at least one caption to save to the database.",
      });
      return;
    }

    setIsSavingToDb(true);
    try {
      const title = state.captionTopic || state.imagePrompt || state.topText || "Untitled Meme";
      const res = await fetch("/api/db/memes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          prompt: state.imagePrompt || state.captionTopic || "",
          top_text: state.topText,
          bottom_text: state.bottomText,
          image_url: state.imageSrc,
          font_family: state.fontFamily,
          text_size: state.textSize,
          text_color: state.textColor,
          stroke_color: state.strokeColor,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to save to database");
      }

      setRefreshDbTrigger((prev) => prev + 1);
      setDbSaveSuccess(true);
      setTimeout(() => setDbSaveSuccess(false), 3500);
      updateState({
        statusText: "Meme saved to SQLite database vault! ✨",
      });
    } catch (err: any) {
      console.error("Database save failed:", err);
      updateState({
        imageError: err.message || "Failed to save meme to database.",
      });
    } finally {
      setIsSavingToDb(false);
    }
  };

  // Load a saved meme from the database into the canvas editor
  const handleLoadFromDatabase = (meme: MemeRecord) => {
    loadImageElement(meme.image_url, () => {
      updateState({
        topText: meme.top_text,
        bottomText: meme.bottom_text,
        fontFamily: meme.font_family || "Impact",
        textSize: meme.text_size || 48,
        textColor: meme.text_color || "#ffffff",
        strokeColor: meme.stroke_color || "#000000",
        captionTopic: meme.title,
        imagePrompt: meme.prompt || "",
        statusText: `Loaded "${meme.title}" from database ✨`,
      });
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  };

  return (
    <div className="min-h-screen bg-[#0f1117] text-[#f3f4f6] flex flex-col items-center py-6 px-4 md:px-8">
      <div className="w-full max-w-7xl flex flex-col gap-6">
        {/* Header Bar */}
        <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-[#2e3440]">
          <div className="flex flex-col">
            <div className="flex items-center gap-3">
              <span className="text-3xl filter drop-shadow">🎭</span>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight bg-gradient-to-r from-indigo-300 via-indigo-500 to-pink-500 bg-clip-text text-transparent">
                AI Meme Generator
              </h1>
            </div>
            <p className="text-xs md:text-sm text-[#9ca3af] mt-1">
              Describe a scene, generate with AI or 100+ templates, save to SQLite database, customize &amp; export
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <a
              href="#database-gallery"
              className="px-3.5 py-2 bg-[#161922] hover:bg-[#1f2430] border border-emerald-500/40 hover:border-emerald-500 text-emerald-300 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Database Vault</span>
            </a>

            <button
              onClick={handleExportZip}
              disabled={isExportingZip}
              className="px-4 py-2 bg-[#1f2430] hover:bg-[#2e3440] border border-pink-500/30 hover:border-pink-500/70 text-white rounded-xl text-xs md:text-sm font-semibold transition flex items-center gap-2 shadow-lg shadow-pink-950/20 cursor-pointer disabled:opacity-50"
              title="Download the full source code project as a .zip file"
            >
              {zipSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-300">Project ZIP Downloaded!</span>
                </>
              ) : isExportingZip ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  <span>Packaging ZIP...</span>
                </>
              ) : (
                <>
                  <FolderDown className="w-4 h-4 text-pink-400" />
                  <span>Download Project ZIP</span>
                </>
              )}
            </button>
          </div>
        </header>

        {dbSaveSuccess && (
          <div className="bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 p-3 rounded-xl flex items-center justify-between text-xs animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span><strong>Meme saved to database!</strong> Check the Database Vault below to view or reload it anytime.</span>
            </div>
            <a href="#database-gallery" className="underline font-bold hover:text-white">
              View in Vault ↓
            </a>
          </div>
        )}

        {/* Main 2-Column Workspace */}
        <main className="grid grid-cols-1 lg:grid-cols-[400px_1fr] gap-6 items-start">
          {/* Left Controls Column */}
          <ControlsPanel
            state={state}
            templates={templates}
            onUpdateState={updateState}
            onGenerateImage={handleGenerateImage}
            onLoadImageUrl={handleLoadImageUrl}
            onGenerateCaption={handleGenerateCaption}
            onAnalyzePrompt={handleAnalyzePrompt}
            onSelectTemplate={handleSelectTemplate}
            onReset={handleReset}
            onDownload={handleDownload}
            onSaveToDatabase={handleSaveToDatabase}
            isSavingToDb={isSavingToDb}
          />

          {/* Right Preview Column */}
          <MemeCanvas
            state={state}
            onUpdateState={updateState}
            onReset={handleReset}
            onUploadImage={handleUploadImage}
            onSaveToDatabase={handleSaveToDatabase}
            isSavingToDb={isSavingToDb}
          />
        </main>

        {/* SQLite Database Vault & Gallery */}
        <div id="database-gallery" className="pt-2">
          <DatabaseGallery
            onLoadMeme={handleLoadFromDatabase}
            refreshTrigger={refreshDbTrigger}
          />
        </div>
      </div>
    </div>
  );
}
