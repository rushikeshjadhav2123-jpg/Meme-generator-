import JSZip from "jszip";

export async function downloadProjectZip() {
  try {
    const res = await fetch("/api/download-zip");
    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "ai-meme-generator.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }
  } catch (err) {
    console.warn("Direct download failed, falling back to client zip generation:", err);
  }

  const zip = new JSZip();

  // 1. Root package.json
  const packageJson = {
    name: "ai-meme-generator",
    version: "1.0.0",
    description: "AI Meme Generator with AI-generated backgrounds and witty captions",
    main: "server.js",
    scripts: {
      start: "node server.js",
      dev: "node --watch server.js"
    },
    dependencies: {
      dotenv: "^16.4.5",
      express: "^4.19.2",
      "@google/genai": "^2.4.0"
    },
    engines: {
      node: ">=18"
    }
  };
  zip.file("package.json", JSON.stringify(packageJson, null, 2));

  // 2. .env.example
  const envExample = `# Copy this file to .env and insert your API keys
# Gemini API Key (recommended, works for both images & captions)
GEMINI_API_KEY="your-gemini-api-key-here"

# Optional: Anthropic Claude Key
ANTHROPIC_API_KEY="sk-ant-your-key-here"

# Optional: OpenAI Key
OPENAI_API_KEY="sk-your-openai-key-here"

PORT=3000
`;
  zip.file(".env.example", envExample);

  // 3. .gitignore
  const gitignore = `node_modules/
.env
dist/
.DS_Store
`;
  zip.file(".gitignore", gitignore);

  // 4. README.md
  const readme = `# AI Meme Generator

A powerful full-stack meme generator where **both the background image and the captions are AI-generated**, then fully customizable and downloadable.

## Features
- **AI Image Generation**: Type any scene prompt (e.g. "a raccoon eating pizza at 3am")
- **AI Caption Generation**: Type a topic and get punchy, comedic Top and Bottom captions
- **Instant Meme Canvas**: Real-time rendering with Impact font, custom outlines, color picker, and font resizing
- **Export & Download**: One-click high-resolution PNG export

## Quick Setup
1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
2. Configure API keys in \`.env\`:
   \`\`\`bash
   cp .env.example .env
   \`\`\`
3. Run the application:
   \`\`\`bash
   npm start
   \`\`\`
4. Open \`http://localhost:3000\` in your browser!
`;
  zip.file("README.md", readme);

  // 5. server.js
  const serverJs = `const express = require("express");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

const CANDIDATE_MODELS = [
  "gemini-3.5-flash-lite",
  "gemini-3.5-flash",
  "gemini-3.7-flash",
  "gemini-3.8-flash"
];

async function generateWithGemini(apiKey, contents, config = {}) {
  const { GoogleGenAI } = require("@google/genai");
  const ai = new GoogleGenAI({ apiKey });
  let lastErr = null;
  for (const model of CANDIDATE_MODELS) {
    try {
      const resp = await ai.models.generateContent({ model, contents, config });
      if (resp && resp.text) {
        return { text: resp.text, model };
      }
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr || new Error("All Gemini models failed.");
}

// --- AI PROMPT ANALYZER ENDPOINT ---
app.post("/api/analyze-prompt", async (req, res) => {
  try {
    const { prompt } = req.body || {};
    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "A 'prompt' string is required." });
    }

    if (process.env.GEMINI_API_KEY) {
      try {
        const sysPrompt = \`You are an elite meme humor theorist and creator. Analyze this user prompt: "\${prompt.trim()}". Return ONLY a JSON object:
{
  "analysis": "1 concise sentence explaining the psychological/comedic reason this scenario is funny or relatable",
  "visualScene": "A vivid description of a comic illustration visual scene capturing this irony without any text",
  "top": "UPPERCASE MEME SETUP (max 6 words)",
  "bottom": "UPPERCASE MEME PUNCHLINE (max 7 words)",
  "alternatives": [
    {"top": "ALT SETUP 1", "bottom": "ALT PUNCHLINE 1"},
    {"top": "ALT SETUP 2", "bottom": "ALT PUNCHLINE 2"}
  ]
}\`;
        const result = await generateWithGemini(process.env.GEMINI_API_KEY, sysPrompt, { responseMimeType: "application/json" });
        const parsed = JSON.parse(result.text.trim());
        return res.json({
          prompt: prompt.trim(),
          analysis: parsed.analysis,
          visualScene: parsed.visualScene,
          top: (parsed.top || "").toUpperCase(),
          bottom: (parsed.bottom || "").toUpperCase(),
          alternatives: parsed.alternatives || [],
          model: result.model
        });
      } catch (err) {
        console.warn("Analyze prompt AI error:", err);
      }
    }

    return res.json({
      prompt: prompt.trim(),
      analysis: "Highlights the relatable tension between expectations and reality.",
      visualScene: \`A dramatic funny illustration depicting \${prompt.trim()}\`,
      top: prompt.trim().toUpperCase(),
      bottom: "AND THEN REALITY HITS",
      alternatives: [{ top: "HOW IT STARTED", bottom: prompt.trim().toUpperCase() }],
      model: "fallback"
    });
  } catch (error) {
    res.status(500).json({ error: "Prompt analysis failed." });
  }
});

// --- AI CAPTION ENDPOINT ---
app.post("/api/generate-caption", async (req, res) => {
  try {
    const { topic, sceneDescription } = req.body || {};
    if (!topic || typeof topic !== "string" || !topic.trim()) {
      return res.status(400).json({ error: "A 'topic' string is required." });
    }

    // Try Gemini if configured
    if (process.env.GEMINI_API_KEY) {
      try {
        const prompt = \`Write a hilarious 2-line meme caption for "\${topic.trim()}". \${sceneDescription ? "The scene shows: " + sceneDescription : ""}. Return ONLY a JSON object: {"analysis": "Brief 1 sentence humor explanation", "top": "SHORT TOP LINE", "bottom": "SHORT BOTTOM LINE", "alternatives": [{"top": "ALT1", "bottom": "ALT1"}]}\`;
        const result = await generateWithGemini(process.env.GEMINI_API_KEY, prompt, { responseMimeType: "application/json" });
        const parsed = JSON.parse(result.text.trim());
        return res.json({
          top: (parsed.top || "").toUpperCase(),
          bottom: (parsed.bottom || "").toUpperCase(),
          analysis: parsed.analysis || null,
          alternatives: parsed.alternatives || [],
          provider: result.model
        });
      } catch (err) {
        console.warn("Gemini error:", err);
      }
    }

    // Fallback caption
    return res.json({
      top: topic.trim().toUpperCase(),
      bottom: "AND IT ACTUALLY WORKS",
      analysis: "Classic punchline format contrasting setup with absurd payoff.",
      alternatives: [{ top: "STAGE 1: PLAN", bottom: topic.trim().toUpperCase() }],
      provider: "fallback"
    });
  } catch (error) {
    res.status(500).json({ error: "Caption generation failed." });
  }
});

// --- AI IMAGE ENDPOINT ---
app.post("/api/generate-image", async (req, res) => {
  try {
    const { prompt } = req.body || {};
    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "A 'prompt' string is required." });
    }

    const clean = prompt.trim();
    const concise = clean.slice(0, 100);
    const pollinationsUrl = \`https://image.pollinations.ai/prompt/\${encodeURIComponent(concise + ", funny comic meme illustration, vibrant, clear subject, no text")}?width=768&height=768&nologo=true\`;

    try {
      const response = await fetch(pollinationsUrl, { signal: AbortSignal.timeout(7500) });
      if (response.ok) {
        const arrayBuffer = await response.arrayBuffer();
        const b64 = Buffer.from(arrayBuffer).toString("base64");
        return res.json({ image: \`data:image/jpeg;base64,\${b64}\` });
      }
    } catch (netErr) {
      // Fallback to high-res template
    }

    return res.json({
      image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1000&q=80"
    });
  } catch (error) {
    res.status(500).json({ error: "Image generation failed." });
  }
});

app.listen(PORT, () => {
  console.log(\`AI Meme Generator running on http://localhost:\${PORT}\`);
});
`;
  zip.file("server.js", serverJs);

  // 6. public/index.html
  const publicIndexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Meme Generator</title>
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Impact&display=swap" rel="stylesheet">
</head>
<body>
  <div class="app-container">
    <header class="header">
      <div class="logo">
        <span class="logo-icon">🎭</span>
        <h1>AI Meme Generator</h1>
      </div>
      <p class="subtitle">Describe a scene, let AI generate the image and captions, then customize and download</p>
    </header>
    <main class="main-content">
      <section class="panel controls-panel">
        <div class="step-box ai-box">
          <div class="step-header">
            <span class="step-number ai-number">01</span>
            <h2>Generate Image</h2>
          </div>
          <div class="input-group">
            <label for="imagePrompt">Describe the meme scene</label>
            <input type="text" id="imagePrompt" placeholder="e.g. a cat confidently walking away from chaos">
          </div>
          <button id="generateImageBtn" class="btn btn-ai btn-full">✨ Generate Image with AI</button>
          <p class="ai-hint">This creates a brand-new background image from your description.</p>
          <p id="imageError" class="ai-error"></p>
        </div>

        <div class="step-box ai-box">
          <div class="step-header">
            <span class="step-number ai-number">02</span>
            <h2>Generate Captions</h2>
          </div>
          <div class="input-group">
            <label for="aiTopic">What's the joke about?</label>
            <input type="text" id="aiTopic" placeholder="e.g. ignoring your problems">
          </div>
          <button id="generateCaptionBtn" class="btn btn-ai btn-full">✨ Generate Captions with AI</button>
          <p class="ai-hint">AI fills in Top/Bottom Text fields below matched to your scene.</p>
          <p id="aiError" class="ai-error"></p>
        </div>

        <div class="step-box">
          <div class="step-header">
            <span class="step-number">03</span>
            <h2>Customize &amp; Style</h2>
          </div>
          <div class="input-group">
            <label for="topText">Top Text</label>
            <input type="text" id="topText" placeholder="WHEN YOU WRITE CODE...">
          </div>
          <div class="input-group">
            <label for="bottomText">Bottom Text</label>
            <input type="text" id="bottomText" placeholder="AND IT WORKS FIRST TRY">
          </div>
          <div class="input-group">
            <label for="textSize">Text Size (<span id="sizeValue">48</span>px)</label>
            <input type="range" id="textSize" min="20" max="80" value="48">
          </div>
          <div class="input-row">
            <div class="input-group">
              <label for="textColor">Text Color</label>
              <input type="color" id="textColor" value="#ffffff">
            </div>
            <div class="input-group">
              <label for="strokeColor">Outline Color</label>
              <input type="color" id="strokeColor" value="#000000">
            </div>
          </div>
          <div class="button-row">
            <button id="downloadButton" class="btn btn-success">💾 Download Image</button>
            <button id="resetButton" class="btn btn-outline">🔄 Reset</button>
          </div>
        </div>
      </section>

      <section class="panel preview-panel">
        <div class="preview-header">
          <h2>Preview</h2>
          <span id="statusText" class="status-message">Ready to create</span>
        </div>
        <div class="canvas-wrapper">
          <div id="emptyState" class="empty-state">
            <div class="empty-icon">🎨</div>
            <h3>No Image Yet</h3>
            <p>Describe a scene above and generate an image to start creating your meme.</p>
          </div>
          <canvas id="memeCanvas"></canvas>
        </div>
      </section>
    </main>
  </div>
  <script src="script.js"></script>
</body>
</html>
`;
  zip.file("public/index.html", publicIndexHtml);

  // 7. public/style.css
  const publicStyleCss = `:root {
  --bg-main: #0f1117;
  --bg-panel: #161922;
  --bg-card: #1f2430;
  --bg-input: #12151d;
  --primary: #6366f1;
  --primary-hover: #4f46e5;
  --success: #10b981;
  --success-hover: #059669;
  --ai: #ec4899;
  --ai-hover: #db2777;
  --text-main: #f3f4f6;
  --text-muted: #9ca3af;
  --border: #2e3440;
  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 16px;
  --transition: all 0.2s ease-in-out;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: 'Inter', system-ui, sans-serif;
  background-color: var(--bg-main);
  color: var(--text-main);
  min-height: 100vh;
  padding: 24px;
  display: flex;
  justify-content: center;
}
.app-container { width: 100%; max-width: 1200px; display: flex; flex-direction: column; gap: 24px; }
.header { text-align: center; margin-bottom: 8px; }
.logo { display: flex; align-items: center; justify-content: center; gap: 12px; }
.logo-icon { font-size: 2rem; }
.logo h1 {
  font-size: 2.2rem;
  font-weight: 800;
  background: linear-gradient(135deg, #a5b4fc 0%, var(--primary) 60%, var(--ai) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.subtitle { color: var(--text-muted); font-size: 0.95rem; margin-top: 6px; }
.main-content { display: grid; grid-template-columns: 400px 1fr; gap: 24px; align-items: start; }
.panel {
  background-color: var(--bg-panel);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}
.controls-panel { display: flex; flex-direction: column; gap: 24px; }
.step-box {
  background-color: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.step-box.ai-box { border-color: rgba(236, 72, 153, 0.35); }
.step-header { display: flex; align-items: center; gap: 12px; }
.step-number {
  background: var(--primary);
  color: #fff;
  font-weight: 700;
  font-size: 0.85rem;
  padding: 4px 10px;
  border-radius: 20px;
}
.step-number.ai-number { background: var(--ai); }
.step-header h2 { font-size: 1.1rem; font-weight: 700; }
.input-group { display: flex; flex-direction: column; gap: 6px; width: 100%; }
.input-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
label { font-size: 0.85rem; font-weight: 600; color: var(--text-muted); }
input[type="text"] {
  width: 100%;
  background-color: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text-main);
  padding: 10px 14px;
  font-family: inherit;
  font-size: 0.9rem;
}
input[type="range"] { accent-color: var(--primary); cursor: pointer; }
input[type="color"] {
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  height: 40px;
  padding: 2px;
  background-color: var(--bg-input);
  cursor: pointer;
}
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 12px 20px;
  font-weight: 600;
  font-size: 0.9rem;
  border-radius: var(--radius-sm);
  border: none;
  cursor: pointer;
}
.btn-full { width: 100%; }
.btn-ai { background-color: var(--ai); color: #fff; }
.btn-success { background-color: var(--success); color: #fff; flex: 1; }
.btn-outline { background-color: transparent; border: 1px solid var(--border); color: var(--text-main); }
.button-row { display: flex; gap: 12px; }
.ai-hint { font-size: 0.78rem; color: var(--text-muted); }
.ai-error { font-size: 0.8rem; color: #f87171; display: none; }
.preview-panel { display: flex; flex-direction: column; gap: 16px; min-height: 500px; }
.preview-header { display: flex; justify-content: space-between; align-items: center; }
.preview-header h2 { font-size: 1.1rem; font-weight: 700; }
.status-message { font-size: 0.85rem; color: var(--text-muted); }
.canvas-wrapper {
  background-color: var(--bg-input);
  border: 2px dashed var(--border);
  border-radius: var(--radius-md);
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  min-height: 450px;
}
canvas { max-width: 100%; max-height: 600px; border-radius: 4px; }
.empty-state { text-align: center; padding: 32px; color: var(--text-muted); }
.empty-icon { font-size: 3rem; margin-bottom: 12px; }
@media (max-width: 900px) {
  .main-content { grid-template-columns: 1fr; }
}
`;
  zip.file("public/style.css", publicStyleCss);

  // 8. public/script.js
  const publicScriptJs = `const imagePromptInput = document.getElementById("imagePrompt");
const generateImageBtn = document.getElementById("generateImageBtn");
const imageError = document.getElementById("imageError");
const aiTopicInput = document.getElementById("aiTopic");
const generateCaptionBtn = document.getElementById("generateCaptionBtn");
const aiError = document.getElementById("aiError");
const topTextInput = document.getElementById("topText");
const bottomTextInput = document.getElementById("bottomText");
const textSizeInput = document.getElementById("textSize");
const sizeValue = document.getElementById("sizeValue");
const textColorInput = document.getElementById("textColor");
const strokeColorInput = document.getElementById("strokeColor");
const downloadButton = document.getElementById("downloadButton");
const resetButton = document.getElementById("resetButton");
const statusText = document.getElementById("statusText");
const emptyState = document.getElementById("emptyState");
const canvas = document.getElementById("memeCanvas");
const ctx = canvas.getContext("2d");

let selectedImage = null;
canvas.style.display = "none";

generateImageBtn.addEventListener("click", async () => {
  const prompt = imagePromptInput.value.trim();
  if (!prompt) return;
  generateImageBtn.disabled = true;
  generateImageBtn.textContent = "Generating...";
  statusText.textContent = "Generating image with AI...";
  try {
    const res = await fetch("/api/generate-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      selectedImage = img;
      emptyState.style.display = "none";
      canvas.style.display = "block";
      drawMeme();
      statusText.textContent = "Image ready ✨";
    };
    img.src = data.image;
  } catch (err) {
    imageError.textContent = "Failed to generate image.";
    imageError.style.display = "block";
  } finally {
    generateImageBtn.disabled = false;
    generateImageBtn.textContent = "✨ Generate Image with AI";
  }
});

generateCaptionBtn.addEventListener("click", async () => {
  const topic = aiTopicInput.value.trim();
  if (!topic) return;
  generateCaptionBtn.disabled = true;
  generateCaptionBtn.textContent = "Generating...";
  statusText.textContent = "Generating captions...";
  try {
    const res = await fetch("/api/generate-caption", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ topic, sceneDescription: imagePromptInput.value })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    topTextInput.value = data.top || "";
    bottomTextInput.value = data.bottom || "";
    drawMeme();
    statusText.textContent = "AI Captions Ready ✨";
  } catch (err) {
    aiError.textContent = "Failed to generate captions.";
    aiError.style.display = "block";
  } finally {
    generateCaptionBtn.disabled = false;
    generateCaptionBtn.textContent = "✨ Generate Captions with AI";
  }
});

function drawMeme() {
  if (!selectedImage) return;
  const maxWidth = 1000;
  const maxHeight = 650;
  let w = selectedImage.naturalWidth || selectedImage.width;
  let h = selectedImage.naturalHeight || selectedImage.height;
  const scale = Math.min(maxWidth / w, maxHeight / h, 1);
  w = Math.round(w * scale);
  h = Math.round(h * scale);
  canvas.width = w;
  canvas.height = h;
  ctx.drawImage(selectedImage, 0, 0, w, h);

  const fontSize = Number(textSizeInput.value) || 48;
  ctx.font = \`900 \${fontSize}px Impact, Arial Black, sans-serif\`;
  ctx.textAlign = "center";
  ctx.fillStyle = textColorInput.value;
  ctx.strokeStyle = strokeColorInput.value;
  ctx.lineWidth = Math.max(4, fontSize / 8);

  const top = topTextInput.value.trim();
  const bottom = bottomTextInput.value.trim();
  if (top) {
    ctx.strokeText(top, w / 2, fontSize + 15);
    ctx.fillText(top, w / 2, fontSize + 15);
  }
  if (bottom) {
    ctx.strokeText(bottom, w / 2, h - 25);
    ctx.fillText(bottom, w / 2, h - 25);
  }
}

[topTextInput, bottomTextInput, textColorInput, strokeColorInput].forEach(el => el.addEventListener("input", drawMeme));
textSizeInput.addEventListener("input", () => {
  sizeValue.textContent = textSizeInput.value;
  drawMeme();
});

downloadButton.addEventListener("click", () => {
  if (!selectedImage) return;
  const link = document.createElement("a");
  link.download = "meme.png";
  link.href = canvas.toDataURL("image/png");
  link.click();
});

resetButton.addEventListener("click", () => {
  imagePromptInput.value = "";
  aiTopicInput.value = "";
  topTextInput.value = "";
  bottomTextInput.value = "";
  selectedImage = null;
  canvas.style.display = "none";
  emptyState.style.display = "block";
  statusText.textContent = "Ready to create";
});
`;
  zip.file("public/script.js", publicScriptJs);

  // Generate zip file blob and trigger download
  const blob = await zip.generateAsync({ type: "blob" });
  const downloadUrl = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = downloadUrl;
  a.download = "ai-meme-generator.zip";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(downloadUrl);
}
