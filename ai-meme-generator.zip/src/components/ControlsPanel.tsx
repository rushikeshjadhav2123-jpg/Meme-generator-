import React, { useState } from "react";
import {
  Sparkles,
  Type,
  Palette,
  Layers,
  Wand2,
  RefreshCw,
  Image as ImageIcon,
  Shuffle,
  ChevronDown,
  BrainCircuit,
  Zap,
  CheckCircle2,
  Search,
  Link as LinkIcon,
  Upload,
  Camera,
  Paintbrush,
  Dices,
  Database,
} from "lucide-react";
import { MemeState, MemeTemplate, CaptionAlternative } from "../types";

interface ControlsPanelProps {
  state: MemeState;
  templates: MemeTemplate[];
  onUpdateState: (updates: Partial<MemeState>) => void;
  onGenerateImage: (overridePrompt?: string, overrideStyle?: "photo" | "comic" | "3d" | "svg") => void;
  onLoadImageUrl: (url: string) => void;
  onGenerateCaption: () => void;
  onAnalyzePrompt: (customPrompt?: string) => void;
  onSelectTemplate: (template: MemeTemplate) => void;
  onReset: () => void;
  onDownload: () => void;
  onSaveToDatabase?: () => void;
  isSavingToDb?: boolean;
}

const TEMPLATE_CATEGORIES = [
  { id: "All", label: "All" },
  { id: "Work", label: "💼 Work & Boss", match: ["work", "boss", "office", "meeting", "job", "career", "corporate", "employee", "business", "money", "paid"] },
  { id: "Trending", label: "🔥 Trending", match: ["drake", "boyfriend", "fine", "button", "harold", "cat", "pikachu", "doge", "uno", "gru", "always", "exit", "batman"] },
  { id: "Panic", label: "😱 Panic & Chaos", match: ["panic", "panik", "fire", "chaos", "scared", "fear", "disaster", "stress", "crying", "dilemma", "headache", "kalm"] },
  { id: "Animals", label: "🐱 Animals", match: ["dog", "cat", "monkey", "pigeon", "butterfly", "seagull", "dinosaur", "cheems", "raccoon", "duck", "kermit"] },
  { id: "Choices", label: "🤔 Choices", match: ["choice", "choose", "button", "dilemma", "prefer", "reject", "change", "mind", "two paths", "trade"] },
  { id: "Tech", label: "💻 Tech & Dev", match: ["developer", "code", "dev", "bug", "laptop", "hack", "computer", "scientist", "brain", "smart"] },
];

const PROMPT_SUGGESTIONS = [
  "my boss called me on weekend",
  "debugging production on Friday 5pm",
  "studying 10 mins before exam",
  "ignoring 500 unread emails",
  "when coffee finally kicks in",
];

const SCENE_SUGGESTIONS = [
  "a cat plotting world domination",
  "a raccoon eating pizza at 3am",
  "developer staring at green terminal",
  "dog sipping tea in burning room",
  "confused robot trying to make coffee",
];

const TOPIC_SUGGESTIONS = [
  "Deploying on Friday 5pm",
  "Fixing a bug with 1 semicolon",
  "When coffee kicks in",
  "AI wrote my homework",
  "Monday morning alarm",
];

export const ControlsPanel: React.FC<ControlsPanelProps> = ({
  state,
  templates,
  onUpdateState,
  onGenerateImage,
  onLoadImageUrl,
  onGenerateCaption,
  onAnalyzePrompt,
  onSelectTemplate,
  onReset,
  onDownload,
  onSaveToDatabase,
  isSavingToDb,
}) => {
  const [unifiedPrompt, setUnifiedPrompt] = useState("");
  const [imageTab, setImageTab] = useState<"templates" | "ai" | "url" | "upload">("templates");
  const [templateSearch, setTemplateSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [customUrlInput, setCustomUrlInput] = useState("");
  const [selectedStyle, setSelectedStyle] = useState<"photo" | "comic" | "3d" | "svg">("photo");

  const filteredTemplates = templates.filter((tpl) => {
    const q = templateSearch.toLowerCase().trim();
    const name = tpl.name.toLowerCase();
    const kws = (tpl as any).keywords || [];
    const matchesSearch =
      !q ||
      name.includes(q) ||
      kws.some((k: string) => k.toLowerCase().includes(q));

    if (!matchesSearch) return false;
    if (selectedCategory === "All") return true;

    const catObj = TEMPLATE_CATEGORIES.find((c) => c.id === selectedCategory);
    if (!catObj || !catObj.match) return true;

    return catObj.match.some(
      (keyword) => name.includes(keyword) || kws.some((k: string) => k.toLowerCase().includes(keyword))
    );
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (typeof event.target?.result === "string") {
          onLoadImageUrl(event.target.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRandomTopic = () => {
    const random = TOPIC_SUGGESTIONS[Math.floor(Math.random() * TOPIC_SUGGESTIONS.length)];
    onUpdateState({ captionTopic: random });
  };

  const handleApplyAlternative = (alt: CaptionAlternative) => {
    onUpdateState({
      topText: alt.top,
      bottomText: alt.bottom,
    });
  };

  const handleRunUnifiedAnalysis = (promptToRun?: string) => {
    const text = promptToRun || unifiedPrompt || state.captionTopic || state.imagePrompt;
    if (text) {
      setUnifiedPrompt(text);
      onAnalyzePrompt(text);
    }
  };

  return (
    <aside className="flex flex-col gap-5 w-full">
      {/* ONE-CLICK AI PROMPT ANALYZER */}
      <div className="bg-gradient-to-br from-[#1a1f2c] via-[#241e33] to-[#1f2430] border-2 border-indigo-500/50 rounded-2xl p-5 shadow-2xl flex flex-col gap-3.5 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
              <BrainCircuit className="w-5 h-5 text-indigo-300 animate-pulse" />
            </div>
            <div>
              <h2 className="text-sm md:text-base font-extrabold text-white flex items-center gap-2">
                <span>AI Prompt Analyzer</span>
                <span className="text-[10px] bg-indigo-500 text-white font-bold px-2 py-0.5 rounded-full tracking-wide">
                  GEMINI AI
                </span>
              </h2>
              <p className="text-[11px] text-[#9ca3af]">
                Type any idea — AI analyzes the humor, generates the scene &amp; punchlines
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <div className="relative flex items-center">
            <input
              type="text"
              id="promptAnalyzerInput"
              value={unifiedPrompt || state.captionTopic || state.imagePrompt}
              onChange={(e) => {
                setUnifiedPrompt(e.target.value);
                onUpdateState({ captionTopic: e.target.value, imagePrompt: e.target.value, captionError: null });
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !state.isAnalyzingPrompt) {
                  handleRunUnifiedAnalysis();
                }
              }}
              placeholder='e.g. "my boss called me on weekend"'
              className="w-full bg-[#0f1219] border border-indigo-500/40 focus:border-indigo-400 rounded-xl text-white px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 transition placeholder-[#6b7280] pr-10"
            />
            {unifiedPrompt && (
              <button
                type="button"
                onClick={() => setUnifiedPrompt("")}
                className="absolute right-3 text-[#6b7280] hover:text-white text-xs cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>

          {/* Quick Prompt Suggestions */}
          <div className="flex flex-wrap gap-1.5">
            {PROMPT_SUGGESTIONS.map((suggestion, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setUnifiedPrompt(suggestion);
                  onUpdateState({ captionTopic: suggestion, imagePrompt: suggestion });
                  handleRunUnifiedAnalysis(suggestion);
                }}
                className="text-[11px] bg-[#12151d] hover:bg-indigo-950/60 text-[#cbd5e1] hover:text-indigo-200 px-2.5 py-1 rounded-lg border border-indigo-900/40 hover:border-indigo-500/50 transition cursor-pointer flex items-center gap-1"
              >
                ⚡ {suggestion}
              </button>
            ))}
          </div>

          <button
            id="analyzePromptBtn"
            disabled={state.isAnalyzingPrompt || state.isGeneratingImage || state.isGeneratingCaption}
            onClick={() => handleRunUnifiedAnalysis()}
            className="w-full py-3 px-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:via-purple-500 hover:to-pink-500 disabled:opacity-60 text-white font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-xl shadow-indigo-950/50 cursor-pointer disabled:cursor-not-allowed"
          >
            {state.isAnalyzingPrompt ? (
              <>
                <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                <span>AI Analyzing Prompt &amp; Composing Meme...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                <span>Analyze Prompt &amp; Generate Meme</span>
              </>
            )}
          </button>
        </div>

        {/* AI Prompt Analysis Display */}
        {state.aiAnalysis && (
          <div className="bg-indigo-950/40 border border-indigo-500/40 rounded-xl p-3 flex flex-col gap-2.5">
            <div className="flex items-center justify-between text-[11px] font-semibold text-indigo-300">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                AI Situation Analysis:
              </span>
              <span className="text-[10px] text-indigo-400 uppercase tracking-wider font-mono">
                {state.aiModelUsed || "Gemini"}
              </span>
            </div>
            <p className="text-xs text-indigo-100 leading-relaxed italic bg-[#0f1219]/60 p-2.5 rounded-lg border border-indigo-900/40">
              "{state.aiAnalysis}"
            </p>

            {/* Matched Iconic Meme Template for this situation */}
            {state.suggestedTemplate && (
              <div className="flex flex-col gap-1.5 pt-1 border-t border-indigo-900/40">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-indigo-300 font-semibold flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    Matched Classic Meme:
                  </span>
                  <span className="text-emerald-400 text-[10px] font-bold">
                    ✓ 100% Authentic Base
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onSelectTemplate(state.suggestedTemplate!)}
                    className="flex-1 flex items-center gap-2 bg-[#0f1219] hover:bg-indigo-950/60 border border-indigo-500/50 hover:border-indigo-400 p-2 rounded-lg transition text-left cursor-pointer group"
                  >
                    <img
                      src={state.suggestedTemplate.url}
                      alt={state.suggestedTemplate.name}
                      className="w-11 h-11 object-cover rounded-md flex-shrink-0 border border-indigo-400/30"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white group-hover:text-indigo-200 truncate">
                        {state.suggestedTemplate.name}
                      </p>
                      <p className="text-[10px] text-[#9ca3af]">Click to apply this template</p>
                    </div>
                  </button>

                  {/* Related alternative templates */}
                  {state.relatedTemplates && state.relatedTemplates.length > 0 && (
                    <div className="flex items-center gap-1.5">
                      {state.relatedTemplates.map((rel) => (
                        <button
                          key={rel.id}
                          type="button"
                          onClick={() => onSelectTemplate(rel)}
                          className="group relative w-11 h-11 rounded-lg overflow-hidden border border-[#2e3440] hover:border-pink-500 transition cursor-pointer"
                          title={`Switch to ${rel.name}`}
                        >
                          <img
                            src={rel.url}
                            alt={rel.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center p-0.5">
                            <span className="text-[9px] text-white font-bold text-center leading-tight truncate">
                              {rel.name.split(" ")[0]}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* STEP 01: MEME IMAGE & BASE (TABS: TEMPLATES, AI GENERATE, URL, UPLOAD) */}
      <div className="bg-[#1f2430] border border-pink-500/30 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="bg-[#ec4899] text-white font-extrabold text-xs px-2.5 py-1 rounded-full tracking-wider shadow-sm">
              01
            </span>
            <h2 className="text-base font-bold text-white tracking-wide">
              Meme Image &amp; Base
            </h2>
          </div>
          <span className="text-xs text-[#9ca3af]">
            {imageTab === "templates" ? `${filteredTemplates.length} templates` : "Custom image"}
          </span>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-4 gap-1 bg-[#12151d] p-1 rounded-xl border border-[#2e3440]">
          <button
            type="button"
            onClick={() => setImageTab("templates")}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${
              imageTab === "templates"
                ? "bg-pink-600 text-white shadow-sm"
                : "text-[#9ca3af] hover:text-white"
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Templates</span>
            <span className="sm:hidden">Memes</span>
          </button>
          <button
            type="button"
            onClick={() => setImageTab("ai")}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${
              imageTab === "ai"
                ? "bg-pink-600 text-white shadow-sm"
                : "text-[#9ca3af] hover:text-white"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Gen</span>
          </button>
          <button
            type="button"
            onClick={() => setImageTab("url")}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${
              imageTab === "url"
                ? "bg-pink-600 text-white shadow-sm"
                : "text-[#9ca3af] hover:text-white"
            }`}
          >
            <LinkIcon className="w-3.5 h-3.5" />
            <span>URL</span>
          </button>
          <button
            type="button"
            onClick={() => setImageTab("upload")}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1 cursor-pointer ${
              imageTab === "upload"
                ? "bg-pink-600 text-white shadow-sm"
                : "text-[#9ca3af] hover:text-white"
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload</span>
          </button>
        </div>

        {/* TAB 1: 100+ MEME TEMPLATES WITH LIVE SEARCH & CATEGORIES */}
        {imageTab === "templates" && (
          <div className="flex flex-col gap-3">
            {/* Search input */}
            <div className="relative flex items-center">
              <Search className="w-4 h-4 text-[#6b7280] absolute left-3 pointer-events-none" />
              <input
                type="text"
                value={templateSearch}
                onChange={(e) => setTemplateSearch(e.target.value)}
                placeholder="Search 100+ memes (boss, dog, panic, drake)..."
                className="w-full bg-[#12151d] border border-[#2e3440] focus:border-pink-500 rounded-xl text-white pl-9 pr-8 py-2 text-xs focus:outline-none transition placeholder-[#6b7280]"
              />
              {templateSearch && (
                <button
                  type="button"
                  onClick={() => setTemplateSearch("")}
                  className="absolute right-2.5 text-[#6b7280] hover:text-white text-xs cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
              {TEMPLATE_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border whitespace-nowrap transition cursor-pointer font-medium ${
                    selectedCategory === cat.id
                      ? "bg-pink-600/30 border-pink-500 text-pink-200"
                      : "bg-[#12151d] border-[#2e3440] text-[#9ca3af] hover:text-white"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Template Grid */}
            <div className="grid grid-cols-3 gap-2 max-h-56 overflow-y-auto pr-1">
              {filteredTemplates.map((tpl) => {
                const isActive = state.imageSrc === tpl.url;
                return (
                  <button
                    key={tpl.id}
                    onClick={() => onSelectTemplate(tpl)}
                    className={`group relative rounded-xl overflow-hidden border transition text-left cursor-pointer aspect-square ${
                      isActive
                        ? "border-pink-500 ring-2 ring-pink-500/60 shadow-lg"
                        : "border-[#2e3440] hover:border-pink-400"
                    }`}
                  >
                    <img
                      src={tpl.url}
                      alt={tpl.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-90 group-hover:opacity-100 transition flex items-end p-1.5">
                      <span className="text-[10px] text-white font-semibold leading-tight line-clamp-2">
                        {tpl.name}
                      </span>
                    </div>
                    {isActive && (
                      <div className="absolute top-1 right-1 bg-pink-600 text-white rounded-full p-0.5 shadow">
                        <CheckCircle2 className="w-3 h-3" />
                      </div>
                    )}
                  </button>
                );
              })}
              {filteredTemplates.length === 0 && (
                <div className="col-span-3 py-6 text-center text-xs text-[#9ca3af] flex flex-col items-center gap-2">
                  <span>No templates found matching "{templateSearch}"</span>
                  <button
                    type="button"
                    onClick={() => {
                      setTemplateSearch("");
                      setSelectedCategory("All");
                    }}
                    className="text-pink-400 hover:underline cursor-pointer"
                  >
                    Clear filter
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: AI IMAGE GENERATOR WITH STYLES */}
        {imageTab === "ai" && (
          <div className="flex flex-col gap-3">
            {/* Style Selector */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-semibold text-[#9ca3af]">AI Visual Style</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {[
                  { id: "photo", label: "📸 Photo", desc: "Realistic" },
                  { id: "comic", label: "🎨 Comic", desc: "Illustration" },
                  { id: "3d", label: "👾 3D Pixar", desc: "Animated" },
                  { id: "svg", label: "🖌️ Vector", desc: "Gemini SVG" },
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedStyle(s.id as any)}
                    className={`p-2 rounded-xl border text-left transition cursor-pointer ${
                      selectedStyle === s.id
                        ? "bg-pink-600/30 border-pink-500 text-pink-200"
                        : "bg-[#12151d] border-[#2e3440] text-[#9ca3af] hover:text-white"
                    }`}
                  >
                    <div className="text-xs font-bold text-white">{s.label}</div>
                    <div className="text-[10px] text-[#9ca3af]">{s.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="imagePrompt" className="text-xs font-semibold text-[#9ca3af]">
                Describe the scene
              </label>
              <input
                type="text"
                id="imagePrompt"
                value={state.imagePrompt}
                onChange={(e) => onUpdateState({ imagePrompt: e.target.value, imageError: null })}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !state.isGeneratingImage) {
                    onGenerateImage(state.imagePrompt, selectedStyle);
                  }
                }}
                placeholder="e.g. stressed worker getting phone call on weekend"
                className="w-full bg-[#12151d] border border-[#2e3440] focus:border-pink-500 rounded-xl text-white px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 transition placeholder-[#6b7280]"
              />
            </div>

            {/* Quick chips */}
            <div className="flex flex-wrap gap-1.5">
              {SCENE_SUGGESTIONS.slice(0, 3).map((suggestion, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => onUpdateState({ imagePrompt: suggestion, imageError: null })}
                  className="text-[11px] bg-[#12151d] hover:bg-[#2e3440] text-[#9ca3af] hover:text-white px-2 py-1 rounded-md border border-[#2e3440] transition cursor-pointer"
                >
                  💡 {suggestion}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-[1fr_auto] gap-2">
              <button
                id="generateImageBtn"
                disabled={state.isGeneratingImage}
                onClick={() => onGenerateImage(state.imagePrompt, selectedStyle)}
                className="py-2.5 px-4 bg-[#ec4899] hover:bg-[#db2777] disabled:opacity-60 text-white font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-pink-950/40 cursor-pointer disabled:cursor-not-allowed"
              >
                {state.isGeneratingImage ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    <span>Generating Scene...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate {selectedStyle.toUpperCase()} Image</span>
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={state.isGeneratingImage}
                onClick={() => onGenerateImage(state.imagePrompt, selectedStyle)}
                title="Roll for a new visual variation with a different seed"
                className="px-3 bg-[#12151d] hover:bg-[#2e3440] border border-[#2e3440] hover:border-pink-500 text-white rounded-xl transition flex items-center justify-center cursor-pointer disabled:opacity-50"
              >
                <Dices className="w-4 h-4 text-pink-400" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: LOAD ANY IMAGE FROM URL */}
        {imageTab === "url" && (
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-[#9ca3af]">
                Paste direct Image URL (JPG, PNG, WEBP)
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customUrlInput}
                  onChange={(e) => setCustomUrlInput(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className="flex-1 bg-[#12151d] border border-[#2e3440] focus:border-pink-500 rounded-xl text-white px-3.5 py-2 text-xs focus:outline-none transition placeholder-[#6b7280]"
                />
                <button
                  type="button"
                  disabled={!customUrlInput.trim()}
                  onClick={() => onLoadImageUrl(customUrlInput)}
                  className="px-3.5 py-2 bg-pink-600 hover:bg-pink-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Load
                </button>
              </div>
            </div>
            <p className="text-[11px] text-[#9ca3af]">
              💡 Tip: You can paste image links from Google Images, Imgur, Reddit, or any web host.
            </p>
          </div>
        )}

        {/* TAB 4: UPLOAD FROM DEVICE */}
        {imageTab === "upload" && (
          <div className="flex flex-col gap-2">
            <label className="flex flex-col items-center justify-center border-2 border-dashed border-[#2e3440] hover:border-pink-500/70 bg-[#12151d] p-6 rounded-2xl transition cursor-pointer group">
              <Upload className="w-8 h-8 text-[#9ca3af] group-hover:text-pink-400 transition mb-2" />
              <span className="text-xs font-bold text-white mb-0.5">Upload Custom Photo</span>
              <span className="text-[10px] text-[#9ca3af]">Click to browse files (PNG, JPG, WEBP)</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        )}

        {state.imageError && (
          <p id="imageError" className="text-xs text-rose-400 bg-rose-950/30 p-2.5 rounded-lg border border-rose-800/40">
            {state.imageError}
          </p>
        )}
      </div>

      {/* STEP 02: GENERATE CAPTIONS */}
      <div className="bg-[#1f2430] border border-pink-500/30 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="bg-[#ec4899] text-white font-extrabold text-xs px-2.5 py-1 rounded-full tracking-wider shadow-sm">
              02
            </span>
            <h2 className="text-base font-bold text-white tracking-wide">
              Generate Captions
            </h2>
          </div>
          <button
            type="button"
            onClick={handleRandomTopic}
            className="text-xs text-[#9ca3af] hover:text-white bg-[#12151d] hover:bg-[#2e3440] border border-[#2e3440] px-2.5 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer"
            title="Surprise Topic"
          >
            <Shuffle className="w-3 h-3 text-pink-400" />
            <span>Random Idea</span>
          </button>
        </div>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="aiTopic" className="text-xs font-semibold text-[#9ca3af]">
            What's the joke about?
          </label>
          <input
            type="text"
            id="aiTopic"
            value={state.captionTopic}
            onChange={(e) => onUpdateState({ captionTopic: e.target.value, captionError: null })}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !state.isGeneratingCaption) onGenerateCaption();
            }}
            placeholder='e.g. ignoring your problems or deploying code'
            className="w-full bg-[#12151d] border border-[#2e3440] focus:border-pink-500 rounded-xl text-white px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 transition placeholder-[#6b7280]"
          />
        </div>

        {/* Topic Quick Chips */}
        <div className="flex flex-wrap gap-1.5">
          {TOPIC_SUGGESTIONS.slice(0, 3).map((topic, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => onUpdateState({ captionTopic: topic, captionError: null })}
              className="text-[11px] bg-[#12151d] hover:bg-[#2e3440] text-[#9ca3af] hover:text-white px-2 py-1 rounded-md border border-[#2e3440] transition cursor-pointer"
            >
              🎯 {topic}
            </button>
          ))}
        </div>

        <button
          id="generateCaptionBtn"
          disabled={state.isGeneratingCaption}
          onClick={onGenerateCaption}
          className="w-full py-2.5 px-4 bg-[#ec4899] hover:bg-[#db2777] disabled:opacity-60 text-white font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-pink-950/40 cursor-pointer disabled:cursor-not-allowed"
        >
          {state.isGeneratingCaption ? (
            <>
              <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              <span>Thinking of Punchlines...</span>
            </>
          ) : (
            <>
              <Wand2 className="w-4 h-4" />
              <span>Generate Captions with AI</span>
            </>
          )}
        </button>

        {/* Alternative punchlines suggestions if available */}
        {state.captionAlternatives && state.captionAlternatives.length > 0 && (
          <div className="flex flex-col gap-1.5 bg-[#12151d] p-3 rounded-xl border border-[#2e3440]">
            <span className="text-[11px] font-semibold text-pink-400">Alternative AI punchlines (click to apply):</span>
            <div className="flex flex-col gap-1.5">
              {state.captionAlternatives.map((alt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleApplyAlternative(alt)}
                  className="text-left text-xs bg-[#1f2430] hover:bg-[#2e3440] p-2 rounded-lg border border-[#2e3440] text-[#e2e8f0] transition cursor-pointer flex flex-col"
                >
                  <span className="text-pink-300 font-bold text-[10px] uppercase">Top: {alt.top}</span>
                  <span className="text-white font-medium text-[11px]">Bottom: {alt.bottom}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        <p className="text-[11px] text-[#9ca3af] leading-relaxed">
          Gemini AI composes punchy, comedic Top and Bottom captions aligned to your joke topic.
        </p>

        {state.captionError && (
          <p id="aiError" className="text-xs text-rose-400 bg-rose-950/30 p-2.5 rounded-lg border border-rose-800/40">
            {state.captionError}
          </p>
        )}
      </div>

      {/* STEP 03: CUSTOMIZE & STYLE */}
      <div className="bg-[#1f2430] border border-[#2e3440] rounded-2xl p-5 shadow-xl flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <span className="bg-[#6366f1] text-white font-extrabold text-xs px-2.5 py-1 rounded-full tracking-wider shadow-sm">
            03
          </span>
          <h2 className="text-base font-bold text-white tracking-wide">
            Customize &amp; Style
          </h2>
        </div>

        {/* Text Inputs */}
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1">
            <label htmlFor="topText" className="text-xs font-semibold text-[#9ca3af]">
              Top Text
            </label>
            <input
              type="text"
              id="topText"
              value={state.topText}
              onChange={(e) => onUpdateState({ topText: e.target.value })}
              placeholder="WHEN YOU WRITE CODE..."
              className="w-full bg-[#12151d] border border-[#2e3440] focus:border-indigo-500 rounded-xl text-white px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition placeholder-[#6b7280]"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label htmlFor="bottomText" className="text-xs font-semibold text-[#9ca3af]">
              Bottom Text
            </label>
            <input
              type="text"
              id="bottomText"
              value={state.bottomText}
              onChange={(e) => onUpdateState({ bottomText: e.target.value })}
              placeholder="AND IT WORKS FIRST TRY"
              className="w-full bg-[#12151d] border border-[#2e3440] focus:border-indigo-500 rounded-xl text-white px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition placeholder-[#6b7280]"
            />
          </div>
        </div>

        {/* Text Size Slider */}
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between items-center">
            <label htmlFor="textSize" className="text-xs font-semibold text-[#9ca3af]">
              Text Size (<span id="sizeValue" className="text-indigo-400 font-bold">{state.textSize}</span>px)
            </label>
            <button
              type="button"
              onClick={() => onUpdateState({ isUppercase: !state.isUppercase })}
              className={`text-[11px] px-2 py-0.5 rounded border transition ${
                state.isUppercase
                  ? "bg-indigo-600 border-indigo-500 text-white"
                  : "bg-[#12151d] border-[#2e3440] text-[#9ca3af]"
              }`}
            >
              ALL CAPS
            </button>
          </div>
          <input
            type="range"
            id="textSize"
            min="20"
            max="80"
            value={state.textSize}
            onChange={(e) => onUpdateState({ textSize: Number(e.target.value) })}
            className="w-full accent-indigo-500 cursor-pointer h-2 bg-[#12151d] rounded-lg"
          />
        </div>

        {/* Font Family Selector */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-semibold text-[#9ca3af]">Font Family</label>
          <select
            value={state.fontFamily}
            onChange={(e) => onUpdateState({ fontFamily: e.target.value })}
            className="w-full bg-[#12151d] border border-[#2e3440] focus:border-indigo-500 rounded-xl text-white px-3 py-2 text-sm focus:outline-none transition cursor-pointer"
          >
            <option value="Impact">Impact (Classic Meme Standard)</option>
            <option value="Anton">Anton (Bold Condensed)</option>
            <option value="Montserrat">Montserrat Black (Modern Heavy)</option>
            <option value="Arial Black">Arial Black (Thick Sans)</option>
          </select>
        </div>

        {/* Color controls */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1">
            <label htmlFor="textColor" className="text-xs font-semibold text-[#9ca3af]">
              Text Color
            </label>
            <div className="flex items-center gap-2 bg-[#12151d] border border-[#2e3440] rounded-xl px-2 py-1.5">
              <input
                type="color"
                id="textColor"
                value={state.textColor}
                onChange={(e) => onUpdateState({ textColor: e.target.value })}
                className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
              />
              <span className="text-xs font-mono text-[#cbd5e1] uppercase">{state.textColor}</span>
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label htmlFor="strokeColor" className="text-xs font-semibold text-[#9ca3af]">
              Outline Color
            </label>
            <div className="flex items-center gap-2 bg-[#12151d] border border-[#2e3440] rounded-xl px-2 py-1.5">
              <input
                type="color"
                id="strokeColor"
                value={state.strokeColor}
                onChange={(e) => onUpdateState({ strokeColor: e.target.value })}
                className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
              />
              <span className="text-xs font-mono text-[#cbd5e1] uppercase">{state.strokeColor}</span>
            </div>
          </div>
        </div>

        {/* Bottom controls buttons */}
        <div className="flex flex-col gap-2 pt-1">
          {onSaveToDatabase && (
            <button
              type="button"
              onClick={onSaveToDatabase}
              disabled={!state.imageElement || isSavingToDb}
              className="w-full py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow-md shadow-indigo-950/30 cursor-pointer disabled:cursor-not-allowed"
            >
              <Database className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isSavingToDb ? "Saving to Database..." : "Save Meme to Database Vault"}</span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={onDownload}
              disabled={!state.imageElement}
              className="py-2.5 px-3 bg-[#10b981] hover:bg-[#059669] disabled:opacity-50 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950/30 cursor-pointer disabled:cursor-not-allowed"
            >
              <span>💾 Download PNG</span>
            </button>
            <button
              type="button"
              onClick={onReset}
              className="py-2.5 px-3 bg-transparent hover:bg-[#12151d] text-white font-semibold text-xs rounded-xl border border-[#2e3440] transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>🔄 Reset All</span>
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
