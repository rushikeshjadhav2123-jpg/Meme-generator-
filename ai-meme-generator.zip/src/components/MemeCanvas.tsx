import React, { useRef, useEffect, useState, useCallback } from "react";
import { Download, Copy, Check, RotateCcw, Upload, Sparkles, Image as ImageIcon, Database } from "lucide-react";
import { MemeState } from "../types";

interface MemeCanvasProps {
  state: MemeState;
  onUpdateState: (updates: Partial<MemeState>) => void;
  onReset: () => void;
  onUploadImage: (file: File) => void;
  onSaveToDatabase?: () => Promise<void> | void;
  isSavingToDb?: boolean;
}

export const MemeCanvas: React.FC<MemeCanvasProps> = ({
  state,
  onUpdateState,
  onReset,
  onUploadImage,
  onSaveToDatabase,
  isSavingToDb,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [copied, setCopied] = useState(false);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  // Redraw canvas whenever relevant state changes
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !state.imageElement) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = state.imageElement;
    const maxWidth = 1000;
    const maxHeight = 750;

    let width = img.naturalWidth || img.width || 800;
    let height = img.naturalHeight || img.height || 600;

    const scale = Math.min(maxWidth / width, maxHeight / height, 1);
    width = Math.round(width * scale);
    height = Math.round(height * scale);

    canvas.width = width;
    canvas.height = height;

    // Draw background image
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);

    const fontSize = state.textSize || 48;
    const fontFamily = state.fontFamily || "Impact";
    ctx.font = `900 ${fontSize}px ${fontFamily}, "Arial Black", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = state.textColor;
    ctx.strokeStyle = state.strokeColor;
    ctx.lineWidth = Math.max(4, fontSize / 8);
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;

    const maxTextWidth = width * 0.9;

    const formatText = (text: string) => {
      if (!text) return "";
      return state.isUppercase ? text.toUpperCase() : text;
    };

    const drawFormattedLines = (text: string, centerY: number) => {
      const formatted = formatText(text.trim());
      if (!formatted) return;

      const words = formatted.split(/\s+/);
      const lines: string[] = [];
      let currentLine = "";

      for (const word of words) {
        const testLine = currentLine ? `${currentLine} ${word}` : word;
        const testWidth = ctx.measureText(testLine).width;
        if (testWidth > maxTextWidth && currentLine) {
          lines.push(currentLine);
          currentLine = word;
        } else {
          currentLine = testLine;
        }
      }
      if (currentLine) lines.push(currentLine);

      const lineHeight = fontSize * 1.1;
      const startY = centerY - ((lines.length - 1) * lineHeight) / 2;

      lines.forEach((line, index) => {
        const lineY = startY + index * lineHeight;
        ctx.strokeText(line, width / 2, lineY);
        ctx.fillText(line, width / 2, lineY);
      });
    };

    // Draw Top Text
    if (state.topText) {
      const topY = fontSize * 0.8 + 20;
      drawFormattedLines(state.topText, topY);
    }

    // Draw Bottom Text
    if (state.bottomText) {
      const bottomY = height - (fontSize * 0.8 + 20);
      drawFormattedLines(state.bottomText, bottomY);
    }
  }, [
    state.imageElement,
    state.topText,
    state.bottomText,
    state.textSize,
    state.textColor,
    state.strokeColor,
    state.fontFamily,
    state.isUppercase,
  ]);

  useEffect(() => {
    renderCanvas();
  }, [renderCanvas]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas || !state.imageElement) return;
    renderCanvas();
    const link = document.createElement("a");
    link.download = `Meme-${Date.now()}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  };

  const handleCopyImage = async () => {
    const canvas = canvasRef.current;
    if (!canvas || !state.imageElement) return;
    try {
      renderCanvas();
      canvas.toBlob(async (blob) => {
        if (!blob) return;
        try {
          await navigator.clipboard.write([
            new ClipboardItem({
              "image/png": blob,
            }),
          ]);
          setCopied(true);
          setTimeout(() => setCopied(false), 2200);
        } catch (err) {
          console.warn("Clipboard write failed:", err);
        }
      });
    } catch (e) {
      console.warn("Copy to clipboard unsupported", e);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith("image/")) {
      onUploadImage(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(true);
  };

  const handleDragLeave = () => {
    setIsDraggingFile(false);
  };

  return (
    <section className="bg-[#161922] border border-[#2e3440] rounded-2xl p-5 md:p-6 shadow-2xl flex flex-col gap-4">
      {/* Canvas Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-[#2e3440]/60">
        <div className="flex items-center gap-2.5">
          <span className="text-xl">🖼️</span>
          <h2 className="text-base md:text-lg font-bold text-white tracking-wide">
            Live Preview
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <span
            id="statusText"
            className="text-xs text-[#9ca3af] bg-[#12151d] px-3 py-1 rounded-full border border-[#2e3440]"
          >
            {state.statusText || "Ready to create"}
          </span>
          {state.imageElement && (
            <button
              onClick={onReset}
              id="resetButton"
              className="text-xs text-[#9ca3af] hover:text-white px-2.5 py-1 rounded-md bg-[#1f2430] hover:bg-[#2e3440] transition flex items-center gap-1"
              title="Reset Generator"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Canvas Display or Empty Dropzone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`relative w-full min-h-[420px] md:min-h-[500px] flex items-center justify-center rounded-xl overflow-hidden transition-all ${
          isDraggingFile
            ? "border-2 border-dashed border-pink-500 bg-pink-950/20"
            : "bg-[#12151d] border-2 border-dashed border-[#2e3440]"
        }`}
      >
        {state.imageElement ? (
          <div className="w-full flex items-center justify-center p-3">
            <canvas
              ref={canvasRef}
              id="memeCanvas"
              className="max-w-full max-h-[620px] rounded-lg shadow-2xl object-contain border border-[#2e3440]/80"
            />
          </div>
        ) : (
          <div
            id="emptyState"
            className="flex flex-col items-center justify-center text-center p-8 max-w-md cursor-pointer group"
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-4 group-hover:scale-105 transition">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">No Image Selected</h3>
            <p className="text-sm text-[#9ca3af] leading-relaxed mb-5">
              Describe a scene on the left to generate with AI, pick a classic template, or click below to upload an image from your device.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                className="px-4 py-2 bg-[#1f2430] hover:bg-[#2e3440] text-sm text-white rounded-lg border border-[#2e3440] transition flex items-center gap-2"
              >
                <Upload className="w-4 h-4 text-indigo-400" />
                <span>Upload Image</span>
              </button>
            </div>
            <span className="text-[11px] text-[#6b7280] mt-3">
              Supports JPG, PNG, WEBP, GIF (drag & drop directly here)
            </span>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onUploadImage(file);
          }}
        />
      </div>

      {/* Action Buttons beneath Canvas */}
      {state.imageElement && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {onSaveToDatabase && (
            <button
              type="button"
              onClick={onSaveToDatabase}
              disabled={isSavingToDb}
              className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white font-semibold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-indigo-950/40 cursor-pointer disabled:cursor-not-allowed"
            >
              {isSavingToDb ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  <span>Saving to DB...</span>
                </>
              ) : (
                <>
                  <Database className="w-4 h-4 text-emerald-300" />
                  <span>Save to Database</span>
                </>
              )}
            </button>
          )}

          <button
            id="downloadButton"
            onClick={handleDownload}
            className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download High-Res PNG</span>
          </button>

          <button
            onClick={handleCopyImage}
            className="w-full py-3 px-4 bg-[#1f2430] hover:bg-[#2e3440] text-white font-medium text-sm rounded-xl border border-[#2e3440] transition flex items-center justify-center gap-2 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-300">Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-indigo-400" />
                <span>Copy Image</span>
              </>
            )}
          </button>
        </div>
      )}
    </section>
  );
};
