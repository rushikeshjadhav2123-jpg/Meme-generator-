import React, { useState, useEffect } from "react";
import {
  Database,
  ThumbsUp,
  Trash2,
  ExternalLink,
  Search,
  Sparkles,
  ArrowUpDown,
  RefreshCw,
  Clock,
  HardDrive,
  Layers,
  CheckCircle2,
} from "lucide-react";
import { MemeRecord, DatabaseStats } from "../types";

interface DatabaseGalleryProps {
  onLoadMeme: (meme: MemeRecord) => void;
  refreshTrigger: number;
}

export const DatabaseGallery: React.FC<DatabaseGalleryProps> = ({
  onLoadMeme,
  refreshTrigger,
}) => {
  const [memes, setMemes] = useState<MemeRecord[]>([]);
  const [stats, setStats] = useState<DatabaseStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"latest" | "popular">("latest");
  const [upvotedIds, setUpvotedIds] = useState<Set<string>>(new Set());
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const fetchMemes = async () => {
    setIsLoading(true);
    try {
      const q = search.trim() ? `?q=${encodeURIComponent(search.trim())}&sort=${sortBy}` : `?sort=${sortBy}`;
      const res = await fetch(`/api/db/memes${q}`);
      const data = await res.json();
      if (data?.memes) {
        setMemes(data.memes);
      }
    } catch (err) {
      console.error("Failed to load memes from database:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/db/stats");
      const data = await res.json();
      if (data?.connected) {
        setStats(data);
      }
    } catch (err) {
      console.error("Failed to load database stats:", err);
    }
  };

  useEffect(() => {
    fetchMemes();
    fetchStats();
  }, [refreshTrigger, sortBy]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchMemes();
  };

  const handleUpvote = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (upvotedIds.has(id)) return;

    try {
      const res = await fetch(`/api/db/memes/${id}/upvote`, { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setUpvotedIds((prev) => new Set([...prev, id]));
        setMemes((prev) =>
          prev.map((m) => (m.id === id ? { ...m, upvotes: (m.upvotes || 0) + 1 } : m))
        );
        fetchStats();
      }
    } catch (err) {
      console.error("Upvote failed:", err);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm("Are you sure you want to remove this meme from the database?")) return;

    try {
      const res = await fetch(`/api/db/memes/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setMemes((prev) => prev.filter((m) => m.id !== id));
        setActionMessage("Meme removed from database");
        setTimeout(() => setActionMessage(null), 3000);
        fetchStats();
      }
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  return (
    <section className="bg-[#161922] border border-[#2e3440] rounded-2xl p-5 md:p-6 shadow-2xl flex flex-col gap-5">
      {/* Header & Database Info */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-[#2e3440]/60">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/30">
            <Database className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white tracking-wide">
                Database Vault &amp; Gallery
              </h2>
              <span className="flex items-center gap-1 text-[11px] bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 px-2.5 py-0.5 rounded-full font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                SQLite 3 Connected
              </span>
            </div>
            <p className="text-xs text-[#9ca3af]">
              Persistent relational database stored in <code className="text-emerald-400 bg-[#12151d] px-1 py-0.5 rounded">data/memes.db</code>
            </p>
          </div>
        </div>

        {stats && (
          <div className="flex items-center gap-3 text-xs bg-[#12151d] border border-[#2e3440] px-3.5 py-2 rounded-xl text-[#cbd5e1]">
            <div className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              <span><strong className="text-white">{stats.totalMemes}</strong> Memes</span>
            </div>
            <span className="text-[#4b5563]">|</span>
            <div className="flex items-center gap-1.5">
              <ThumbsUp className="w-3.5 h-3.5 text-pink-400" />
              <span><strong className="text-white">{stats.totalUpvotes}</strong> Upvotes</span>
            </div>
            <span className="text-[#4b5563]">|</span>
            <div className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
              <span>{(stats.fileSizeBytes / 1024).toFixed(1)} KB</span>
            </div>
          </div>
        )}
      </div>

      {actionMessage && (
        <div className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs px-3 py-2 rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Search and Sort Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-[#6b7280] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved memes in database..."
            className="w-full bg-[#12151d] border border-[#2e3440] focus:border-indigo-500 rounded-xl text-white pl-9 pr-8 py-2 text-xs focus:outline-none transition placeholder-[#6b7280]"
          />
          {search && (
            <button
              type="button"
              onClick={() => { setSearch(""); fetchMemes(); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6b7280] hover:text-white text-xs cursor-pointer"
            >
              ✕
            </button>
          )}
        </form>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <div className="flex items-center bg-[#12151d] p-1 rounded-xl border border-[#2e3440] text-xs font-semibold">
            <button
              type="button"
              onClick={() => setSortBy("latest")}
              className={`px-3 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer ${
                sortBy === "latest" ? "bg-indigo-600 text-white" : "text-[#9ca3af] hover:text-white"
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Latest</span>
            </button>
            <button
              type="button"
              onClick={() => setSortBy("popular")}
              className={`px-3 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer ${
                sortBy === "popular" ? "bg-indigo-600 text-white" : "text-[#9ca3af] hover:text-white"
              }`}
            >
              <ArrowUpDown className="w-3 h-3" />
              <span>Most Upvoted</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => { fetchMemes(); fetchStats(); }}
            title="Refresh database"
            className="p-2 bg-[#12151d] hover:bg-[#1f2430] border border-[#2e3440] text-[#9ca3af] hover:text-white rounded-xl transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Grid of Saved Memes from Database */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {memes.map((m) => {
          const isUpvoted = upvotedIds.has(m.id);
          return (
            <div
              key={m.id}
              className="group bg-[#12151d] border border-[#2e3440] hover:border-indigo-500/60 rounded-xl overflow-hidden flex flex-col transition duration-200 shadow-md hover:shadow-xl"
            >
              {/* Meme Visual Preview Card */}
              <div className="relative aspect-[4/3] bg-black/40 overflow-hidden flex items-center justify-center">
                <img
                  src={m.image_url}
                  alt={m.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />

                {/* Overlay Text Preview */}
                <div className="absolute inset-0 p-2 flex flex-col justify-between pointer-events-none bg-gradient-to-b from-black/40 via-transparent to-black/60">
                  <p
                    className="text-center font-black leading-tight text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] uppercase text-xs"
                    style={{ fontFamily: m.font_family || "Impact" }}
                  >
                    {m.top_text}
                  </p>
                  <p
                    className="text-center font-black leading-tight text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] uppercase text-xs"
                    style={{ fontFamily: m.font_family || "Impact" }}
                  >
                    {m.bottom_text}
                  </p>
                </div>

                {/* Quick Action Overlay on Hover */}
                <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2 p-3">
                  <button
                    type="button"
                    onClick={() => onLoadMeme(m)}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition flex items-center gap-1.5 shadow-lg cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Load into Editor</span>
                  </button>
                </div>
              </div>

              {/* Meme Card Meta & Actions */}
              <div className="p-3 flex flex-col gap-2 flex-1 justify-between">
                <div>
                  <h3 className="text-xs font-bold text-white truncate" title={m.title}>
                    {m.title}
                  </h3>
                  {m.prompt && (
                    <p className="text-[10px] text-[#9ca3af] truncate" title={m.prompt}>
                      Prompt: "{m.prompt}"
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-[#2e3440]/60">
                  <button
                    type="button"
                    onClick={(e) => handleUpvote(m.id, e)}
                    className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md transition cursor-pointer ${
                      isUpvoted
                        ? "bg-pink-900/40 text-pink-300 border border-pink-500/40"
                        : "bg-[#1f2430] hover:bg-[#2e3440] text-[#9ca3af] hover:text-white border border-[#2e3440]"
                    }`}
                  >
                    <ThumbsUp className={`w-3 h-3 ${isUpvoted ? "text-pink-400 fill-pink-400" : ""}`} />
                    <span>{m.upvotes || 0}</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onLoadMeme(m)}
                      title="Load into Canvas"
                      className="p-1 hover:bg-[#1f2430] text-[#9ca3af] hover:text-indigo-300 rounded transition cursor-pointer"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleDelete(m.id, e)}
                      title="Delete from database"
                      className="p-1 hover:bg-rose-950/40 text-[#9ca3af] hover:text-rose-400 rounded transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {memes.length === 0 && !isLoading && (
        <div className="py-12 text-center text-[#9ca3af] flex flex-col items-center justify-center gap-2">
          <Database className="w-8 h-8 text-[#4b5563]" />
          <p className="text-sm font-semibold text-white">No memes found in the database</p>
          <p className="text-xs text-[#9ca3af]">
            Create a meme above and click <strong>"Save to Database"</strong> to store it in SQLite!
          </p>
        </div>
      )}
    </section>
  );
};
