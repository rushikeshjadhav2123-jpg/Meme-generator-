import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import { dbService } from "./src/db/database";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Initialize Gemini SDK with User-Agent header
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Curated authentic iconic meme templates with verified CDN URLs
const MEME_TEMPLATES = [
  {
    id: "this-is-fine",
    name: "This Is Fine (Dog in Fire)",
    url: "https://i.imgflip.com/wxica.jpg",
    defaultTop: "EVERYTHING IS ON FIRE",
    defaultBottom: "THIS IS FINE",
    keywords: ["fine", "fire", "burn", "chaos", "crisis", "disaster", "weekend", "work", "calm", "relax"]
  },
  {
    id: "boardroom-meeting",
    name: "Boardroom Meeting (Boss Throw)",
    url: "https://i.imgflip.com/m78d.jpg",
    defaultTop: "HOW CAN WE CELEBRATE THE WEEKEND?",
    defaultBottom: "CALL EMPLOYEES ON SUNDAY",
    keywords: ["boss", "meeting", "work", "office", "manager", "employee", "corporate", "job", "career", "weekend"]
  },
  {
    id: "hide-pain-harold",
    name: "Hide the Pain Harold",
    url: "https://i.imgflip.com/gk5el.jpg",
    defaultTop: "WHEN BOSS SAYS QUICK 5 MIN CALL",
    defaultBottom: "ON SATURDAY AFTERNOON",
    keywords: ["pain", "smile", "harold", "boss", "weekend", "awkward", "dying inside", "suffering", "pretend", "work", "call"]
  },
  {
    id: "panik-kalm-panik",
    name: "Panik Kalm Panik",
    url: "https://i.imgflip.com/3qqcim.png",
    defaultTop: "WEEKEND STARTS (KALM)",
    defaultBottom: "PHONE RINGS: 'BOSS' (PANIK)",
    keywords: ["panic", "panik", "kalm", "scared", "fear", "alarm", "call", "shock", "exam", "test", "boss", "emergency"]
  },
  {
    id: "distracted-bf",
    name: "Distracted Boyfriend",
    url: "https://i.imgflip.com/1ur9b0.jpg",
    defaultTop: "NEW SHINY PROJECT",
    defaultBottom: "MY PENDING PRODUCTION BUGS",
    keywords: ["boyfriend", "girlfriend", "distracted", "choice", "temptation", "shiny", "new", "looking", "cheat", "side"]
  },
  {
    id: "two-buttons",
    name: "Two Buttons (Sweating Guy)",
    url: "https://i.imgflip.com/1g8my4.jpg",
    defaultTop: "ANSWER BOSS ON WEEKEND",
    defaultBottom: "PRETEND PHONE BATTERY DIED",
    keywords: ["buttons", "sweat", "choice", "dilemma", "struggle", "decision", "hard", "choose", "boss"]
  },
  {
    id: "drake-hotline",
    name: "Drake Hotline Bling",
    url: "https://i.imgflip.com/30b1gx.jpg",
    defaultTop: "ANSWERING WORK CALLS ON SUNDAY",
    defaultBottom: "TURNING ON AIRPLANE MODE",
    keywords: ["drake", "hotline", "like", "dislike", "prefer", "no", "yes", "better", "reject"]
  },
  {
    id: "woman-yelling-cat",
    name: "Woman Yelling at Cat",
    url: "https://i.imgflip.com/345v97.jpg",
    defaultTop: "YOU WERE SUPPOSED TO REPLY INSTANTLY!",
    defaultBottom: "ME ENJOYING MY SATURDAY NAP",
    keywords: ["woman", "cat", "yell", "dinner", "salad", "argue", "fight", "blame", "innocent", "yelling"]
  },
  {
    id: "surprised-pikachu",
    name: "Surprised Pikachu",
    url: "https://i.imgflip.com/2kbn1e.jpg",
    defaultTop: "OPENS WORK SLACK ON SATURDAY",
    defaultBottom: "GETS ASSIGNED AN URGENT BUG",
    keywords: ["pikachu", "surprised", "shock", "unexpected", "consequences", "reaction", "pokemon", "mouth"]
  },
  {
    id: "buff-doge",
    name: "Buff Doge vs. Cheems",
    url: "https://i.imgflip.com/43a45p.png",
    defaultTop: "ME PLANNING MY WEEKEND ON FRIDAY",
    defaultBottom: "ME WHEN BOSS CALLS ON SUNDAY",
    keywords: ["doge", "cheems", "buff", "weak", "strong", "past", "present", "expectation", "reality", "dog"]
  },
  {
    id: "disaster-girl",
    name: "Disaster Girl",
    url: "https://i.imgflip.com/23ls.jpg",
    defaultTop: "PRODUCTION SERVER IS CRASHING",
    defaultBottom: "ME CLOCKING OUT AT 5 PM",
    keywords: ["disaster", "fire", "girl", "evil", "chaos", "burn", "ruin", "house", "smile"]
  },
  {
    id: "uno-draw-25",
    name: "UNO Draw 25 Cards",
    url: "https://i.imgflip.com/3lmzyx.jpg",
    defaultTop: "PICK UP THE WORK CALL",
    defaultBottom: "OR DRAW 25 CARDS",
    keywords: ["uno", "cards", "draw", "refuse", "never", "hate", "rather", "game"]
  },
  {
    id: "change-my-mind",
    name: "Change My Mind",
    url: "https://i.imgflip.com/24y43o.jpg",
    defaultTop: "WEEKENDS ARE STRICTLY FOR RELAXING",
    defaultBottom: "CHANGE MY MIND",
    keywords: ["mind", "change", "table", "crowder", "opinion", "fact", "debate", "prove"]
  },
  {
    id: "sad-pablo",
    name: "Sad Pablo Escobar",
    url: "https://i.imgflip.com/1c1uej.jpg",
    defaultTop: "WAITING FOR MONDAY MORNING",
    defaultBottom: "SAID NO ONE EVER",
    keywords: ["pablo", "sad", "waiting", "bored", "alone", "narcos", "lonely", "swing"]
  },
  {
    id: "clown-makeup",
    name: "Clown Applying Makeup",
    url: "https://i.imgflip.com/38el31.jpg",
    defaultTop: "I WILL JUST CHECK ONE EMAIL",
    defaultBottom: "NOW WORKING ALL WEEKEND",
    keywords: ["clown", "makeup", "fool", "dumb", "mistake", "regret", "steps", "progression"]
  },
  {
    id: "futurama-fry",
    name: "Futurama Fry (Not Sure If)",
    url: "https://i.imgflip.com/1bgw.jpg",
    defaultTop: "NOT SURE IF BOSS IS JOKING",
    defaultBottom: "OR ACTUALLY EXPECTING ME TO WORK",
    keywords: ["fry", "futurama", "squint", "not sure", "suspicious", "doubt", "skeptical"]
  },
  {
    id: "roll-safe",
    name: "Roll Safe (Think About It)",
    url: "https://i.imgflip.com/1h7in3.jpg",
    defaultTop: "CANT GET CALLED ON WEEKEND",
    defaultBottom: "IF YOU TURN AIRPLANE MODE ON",
    keywords: ["roll safe", "smart", "brain", "think", "clever", "hack", "lifehack", "logic"]
  },
  {
    id: "bernie-asking",
    name: "Bernie I Am Once Again Asking",
    url: "https://i.imgflip.com/3oevdk.jpg",
    defaultTop: "I AM ONCE AGAIN ASKING",
    defaultBottom: "WHY YOU ARE CALLING ME ON SUNDAY",
    keywords: ["bernie", "asking", "support", "again", "coat", "financial", "plea", "politician"]
  }
];

// Fallback witty captions if APIs are offline
const FALLBACK_CAPTIONS = [
  { top: "WHEN THE CODE COMPILES", bottom: "WITHOUT A SINGLE WARNING" },
  { top: "ONE DOES NOT SIMPLY", bottom: "EXIT VIM" },
  { top: "IT'S NOT A BUG", bottom: "IT'S AN UNDOCUMENTED FEATURE" },
  { top: "ME EXPLAINING MY CODE", bottom: "TO PAST ME WHO WROTE IT" },
  { top: "TESTING IN PRODUCTION", bottom: "WHAT COULD POSSIBLY GO WRONG" },
  { top: "PUSHED TO PROD ON FRIDAY", bottom: "TURNED PHONE OFF IMMEDIATELY" },
  { top: "STARE AT CODE FOR 3 HOURS", bottom: "MISSING SEMICOLON FOUND" }
];

// High-availability prioritized Gemini text models
const CANDIDATE_GEMINI_MODELS = [
  "gemini-3.5-flash-lite",
  "gemini-3.5-flash",
  "gemini-3.7-flash",
  "gemini-3.8-flash"
];

// Track image generation quota availability to prevent repeated 429s when quota is 0
let geminiImageQuotaAvailable: boolean | null = null;

// Helper to reliably generate content with Gemini failover across available models
async function generateWithGemini(prompt: string, systemInstruction?: string, isJson: boolean = false) {
  const gemini = getGeminiClient();
  if (!gemini) return null;

  for (const model of CANDIDATE_GEMINI_MODELS) {
    try {
      const config: any = {};
      if (isJson) config.responseMimeType = "application/json";
      if (systemInstruction) config.systemInstruction = systemInstruction;

      const response = await gemini.models.generateContent({
        model,
        contents: prompt,
        config
      });

      if (response && response.text) {
        return { text: response.text, model };
      }
    } catch (err: any) {
      console.log(`[Info] Model ${model} unavailable (${err?.status || err?.message}), trying next candidate...`);
    }
  }
  return null;
}

// Health endpoint
app.get("/api/health", (_req: Request, res: Response) => {
  res.json({
    status: "ok",
    hasGemini: !!process.env.GEMINI_API_KEY,
    hasAnthropic: !!process.env.ANTHROPIC_API_KEY,
    hasOpenAI: !!process.env.OPENAI_API_KEY,
  });
});

let ALL_TEMPLATES: any[] = [...MEME_TEMPLATES];

async function initTemplates() {
  try {
    const res = await fetch("https://api.imgflip.com/get_memes");
    if (res.ok) {
      const json = await res.json();
      if (json.success && Array.isArray(json.data?.memes)) {
        const existingUrls = new Set(MEME_TEMPLATES.map((t) => t.url));
        const extraMemes = json.data.memes
          .filter((m: any) => !existingUrls.has(m.url))
          .map((m: any) => ({
            id: `imgflip-${m.id}`,
            name: m.name,
            url: m.url,
            defaultTop: "WHEN YOU REALIZE",
            defaultBottom: m.name.toUpperCase(),
            keywords: m.name.toLowerCase().split(/[\s,()\-]+/).filter((w: string) => w.length > 2),
            boxCount: m.box_count || 2,
          }));
        ALL_TEMPLATES = [...MEME_TEMPLATES, ...extraMemes];
        console.log(`[Info] Initialized ${ALL_TEMPLATES.length} total meme templates.`);
      }
    }
  } catch (err) {
    console.log("[Info] Imgflip template sync skipped:", err);
  }
}
initTemplates();

// Template list endpoint with real-time search & categories
app.get("/api/templates", (req: Request, res: Response) => {
  const query = typeof req.query.q === "string" ? req.query.q.toLowerCase().trim() : "";
  if (!query) {
    return res.json({ templates: ALL_TEMPLATES });
  }
  const filtered = ALL_TEMPLATES.filter((t) => {
    if (t.name.toLowerCase().includes(query)) return true;
    if (t.keywords && t.keywords.some((kw: string) => kw.toLowerCase().includes(query))) return true;
    return false;
  });
  return res.json({ templates: filtered });
});

// ZIP Download endpoint: serves the complete packaged project
app.get(["/api/download-zip", "/download-zip", "/ai-meme-generator.zip"], (req: Request, res: Response) => {
  const zipPath = path.join(process.cwd(), "public", "ai-meme-generator.zip");
  if (fs.existsSync(zipPath)) {
    res.setHeader("Content-Disposition", 'attachment; filename="ai-meme-generator.zip"');
    res.setHeader("Content-Type", "application/zip");
    return res.sendFile(zipPath);
  }
  return res.status(404).json({ error: "ZIP file not found." });
});

// --- SQLITE DATABASE API ENDPOINTS ---

// 1. Get all saved memes (supports ?q=search and ?sort=latest|popular)
app.get("/api/db/memes", (req: Request, res: Response) => {
  try {
    const q = typeof req.query.q === "string" ? req.query.q : undefined;
    const sort = req.query.sort === "popular" ? "popular" : "latest";
    const memes = dbService.getMemes(q, sort);
    return res.json({ memes, count: memes.length });
  } catch (err: any) {
    console.error("DB getMemes error:", err);
    return res.status(500).json({ error: "Failed to load memes from database." });
  }
});

// 2. Save a meme to database
app.post("/api/db/memes", (req: Request, res: Response) => {
  try {
    const { title, prompt, top_text, bottom_text, image_url, font_family, text_size, text_color, stroke_color } = req.body || {};
    if (!image_url || (!top_text && !bottom_text)) {
      return res.status(400).json({ error: "Image and at least one caption are required to save to database." });
    }

    const saved = dbService.saveMeme({
      title: title || top_text || "Untitled Meme",
      prompt,
      top_text: top_text || "",
      bottom_text: bottom_text || "",
      image_url,
      font_family: font_family || "Impact",
      text_size: Number(text_size) || 48,
      text_color: text_color || "#ffffff",
      stroke_color: stroke_color || "#000000",
    });

    return res.status(201).json({ success: true, meme: saved });
  } catch (err: any) {
    console.error("DB saveMeme error:", err);
    return res.status(500).json({ error: "Failed to save meme to database." });
  }
});

// 3. Upvote a meme
app.post("/api/db/memes/:id/upvote", (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const result = dbService.upvoteMeme(id);
    if (!result) return res.status(404).json({ error: "Meme not found." });
    return res.json({ success: true, upvotes: result.upvotes });
  } catch (err: any) {
    console.error("DB upvote error:", err);
    return res.status(500).json({ error: "Failed to upvote meme." });
  }
});

// 4. Delete a meme
app.delete("/api/db/memes/:id", (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const deleted = dbService.deleteMeme(id);
    if (!deleted) return res.status(404).json({ error: "Meme not found." });
    return res.json({ success: true, message: "Meme deleted successfully." });
  } catch (err: any) {
    console.error("DB delete error:", err);
    return res.status(500).json({ error: "Failed to delete meme." });
  }
});

// 5. Database health & statistics
app.get("/api/db/stats", (_req: Request, res: Response) => {
  try {
    const stats = dbService.getStats();
    return res.json(stats);
  } catch (err: any) {
    console.error("DB stats error:", err);
    return res.status(500).json({ error: "Failed to fetch database stats." });
  }
});

// --- DEDICATED AI PROMPT ANALYZER ---
// Thoroughly breaks down any user prompt (scene, situation, joke, topic) into:
// 1. Humor analysis & insight
// 2. Optimized visual scene for image generation
// 3. Punchy Top/Bottom meme text
// 4. Multiple alternative punchlines
// 5. Matched authentic iconic meme template & related templates
app.post("/api/analyze-prompt", async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body || {};
    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "A prompt string is required." });
    }

    const trimmed = prompt.trim();
    const matchedTemplate = findMatchingTemplate(trimmed);
    const relatedTemplates = findRelatedTemplates(trimmed, matchedTemplate.id);

    const systemInstruction = `You are an expert cultural humor analyst and viral meme creator.
Deeply analyze the user's prompt (relatable situation, complaint, joke idea, everyday irony, or scene).
Produce a complete structured meme breakdown:
1. "analysis": A clear 1-2 sentence explanation of the relatable truth, emotional contrast, or irony captured in this prompt.
2. "visualScene": A vivid, descriptive prompt for an image generator illustrating the scene (comic/illustration style, clear focal subject, expressive funny facial expression, high contrast, leave open margins for captions, strictly NO words or text rendered).
3. "top": Punchy setup caption in ALL CAPS (under 7 words).
4. "bottom": Punchy twist/punchline caption in ALL CAPS (under 7 words).
5. "alternatives": Array of 3 distinct { "top": "...", "bottom": "..." } caption variations.
Return strictly valid JSON matching this schema.`;

    const result = await generateWithGemini(
      `Analyze user prompt: "${trimmed}"`,
      systemInstruction,
      true
    );

    if (result && result.text) {
      const parsed = JSON.parse(result.text.replace(/```json|```/g, "").trim());
      try {
        dbService.logPromptAnalysis(trimmed, parsed.analysis || "", result.model);
      } catch (logErr) {
        console.warn("Prompt logging error:", logErr);
      }
      return res.json({
        prompt: trimmed,
        analysis: parsed.analysis || `Analyzed relatable irony in: "${trimmed}"`,
        visualScene: parsed.visualScene || `A comic-style illustration representing ${trimmed}, vivid colors, no text`,
        top: String(parsed.top || "").toUpperCase(),
        bottom: String(parsed.bottom || "").toUpperCase(),
        alternatives: Array.isArray(parsed.alternatives)
          ? parsed.alternatives.map((a: any) => ({
              top: String(a.top || "").toUpperCase(),
              bottom: String(a.bottom || "").toUpperCase(),
            }))
          : [],
        suggestedTemplate: matchedTemplate,
        relatedTemplates,
        model: result.model,
      });
    }

    // Dynamic smart analysis fallback
    return res.json({
      prompt: trimmed,
      analysis: `Examined situation: "${trimmed}". Contrasted ideal expectations against chaotic reality.`,
      visualScene: `A comic-book illustration of ${trimmed}, dramatic expressive characters, high contrast, uncluttered space`,
      top: `WHEN ${trimmed.toUpperCase()}`,
      bottom: "AND YOU HAVE TO ACT NORMAL",
      alternatives: [
        { top: `MY PLANS: PEACEFUL DAY`, bottom: `${trimmed.toUpperCase()}: ALLOW ME TO INTRODUCE MYSELF` },
        { top: `STAGE 1: DENIAL`, bottom: `STAGE 2: ${trimmed.toUpperCase()}` },
      ],
      suggestedTemplate: matchedTemplate,
      relatedTemplates,
      model: "smart-fallback",
    });
  } catch (err: any) {
    console.error("Error in /api/analyze-prompt:", err);
    return res.status(500).json({ error: err.message || "Failed to analyze prompt." });
  }
});

// --- AI CAPTION GENERATION ---
app.post("/api/generate-caption", async (req: Request, res: Response) => {
  try {
    const { topic, sceneDescription } = req.body || {};

    const rawTopic = (topic && typeof topic === "string" && topic.trim())
      ? topic.trim()
      : (sceneDescription && typeof sceneDescription === "string" && sceneDescription.trim())
      ? sceneDescription.trim()
      : "";

    if (!rawTopic) {
      return res.status(400).json({ error: "A topic or prompt is required to generate captions." });
    }

    const trimmedScene = typeof sceneDescription === "string" ? sceneDescription.trim() : "";

    // 1. Try Gemini with candidate models
    const prompt = `Analyze this user topic or joke idea: "${rawTopic}".
${trimmedScene ? `The background scene shows: "${trimmedScene}".` : ""}
Provide:
1. "analysis": 1-sentence insight explaining the humor/irony.
2. "top": One main top caption (under 7 words each, all caps, punchy, witty).
3. "bottom": One main bottom caption (under 7 words each, all caps, punchy, witty).
4. "alternatives": Three distinct alternative caption ideas { "top": "...", "bottom": "..." } for variety.
Return strictly valid JSON.`;

    const geminiResult = await generateWithGemini(
      prompt,
      "You are an award-winning meme creator on Reddit/Twitter. You write genuinely funny, relatable, punchy captions in standard meme structure (Setup on top, twist/punchline on bottom). Never repeat the prompt literally.",
      true
    );

    if (geminiResult && geminiResult.text) {
      const parsed = JSON.parse(geminiResult.text.replace(/```json|```/g, "").trim());
      if (parsed && (parsed.top || parsed.bottom)) {
        return res.json({
          analysis: parsed.analysis || `Analyzed prompt: "${rawTopic}"`,
          top: String(parsed.top || "").toUpperCase(),
          bottom: String(parsed.bottom || "").toUpperCase(),
          alternatives: Array.isArray(parsed.alternatives)
            ? parsed.alternatives.map((a: { top?: string; bottom?: string }) => ({
                top: String(a.top || "").toUpperCase(),
                bottom: String(a.bottom || "").toUpperCase(),
              }))
            : [],
          provider: geminiResult.model,
        });
      }
    }

    // 2. Try Anthropic if ANTHROPIC_API_KEY is configured
    if (process.env.ANTHROPIC_API_KEY) {
      try {
        const anthropicPrompt = `Write a two-line meme caption for the topic: "${rawTopic}"${
          trimmedScene ? ` The meme image shows: "${trimmedScene}".` : ""
        }. Return ONLY a JSON object: {"top": "SHORT TOP LINE", "bottom": "SHORT BOTTOM LINE"}. Each line under 8 words, punchy, ALL CAPS.`;

        const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": process.env.ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: "claude-sonnet-4-6",
            max_tokens: 1000,
            messages: [{ role: "user", content: anthropicPrompt }],
          }),
        });

        if (anthropicRes.ok) {
          const data = (await anthropicRes.json()) as { content?: Array<{ type: string; text?: string }> };
          const textBlock = (data.content || []).find((item) => item.type === "text");
          if (textBlock?.text) {
            const parsed = JSON.parse(textBlock.text.replace(/```json|```/g, "").trim());
            return res.json({
              analysis: `Analyzed topic: "${rawTopic}"`,
              top: String(parsed.top || "").toUpperCase(),
              bottom: String(parsed.bottom || "").toUpperCase(),
              alternatives: [],
              provider: "anthropic",
            });
          }
        }
      } catch (anthropicErr) {
        console.warn("Anthropic caption generation error:", anthropicErr);
      }
    }

    // 3. Fallback smart caption generator tailored to prompt
    return res.json({
      analysis: `Analyzed humor around: "${rawTopic}"`,
      top: `WHEN ${rawTopic.toUpperCase()}`,
      bottom: "AND EVERYTHING GOES ACCORDING TO PLAN... NOT",
      alternatives: [
        { top: `MY CONFIDENCE: 100%`, bottom: `${rawTopic.toUpperCase()}: 0%` },
        { top: `EXPLAINING ${rawTopic.toUpperCase()}`, bottom: "TO SOMEONE WHO DOESN'T GET IT" }
      ],
      provider: "smart-fallback",
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : "Internal caption error";
    console.error("Error generating caption:", err);
    return res.status(500).json({ error: errorMsg });
  }
});

// Helper to match the most appropriate iconic meme template based on user prompt
function findMatchingTemplate(query: string) {
  const q = (query || "").toLowerCase();

  // High-priority situational & keyword matches
  if (
    q.includes("boss") ||
    q.includes("work") ||
    q.includes("meeting") ||
    q.includes("office") ||
    q.includes("corporate") ||
    q.includes("manager") ||
    q.includes("employee") ||
    q.includes("job") ||
    q.includes("career")
  ) {
    if (
      q.includes("call") ||
      q.includes("weekend") ||
      q.includes("sunday") ||
      q.includes("pain") ||
      q.includes("smile") ||
      q.includes("afternoon")
    ) {
      return MEME_TEMPLATES.find((t) => t.id === "hide-pain-harold") || MEME_TEMPLATES[2];
    }
    return MEME_TEMPLATES.find((t) => t.id === "boardroom-meeting") || MEME_TEMPLATES[1];
  }

  if (
    q.includes("fine") ||
    q.includes("fire") ||
    q.includes("burn") ||
    q.includes("chaos") ||
    q.includes("crisis") ||
    q.includes("disaster") ||
    q.includes("everything")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "this-is-fine") || MEME_TEMPLATES[0];
  }

  if (
    q.includes("panic") ||
    q.includes("panik") ||
    q.includes("scared") ||
    q.includes("fear") ||
    q.includes("alarm") ||
    q.includes("emergency") ||
    q.includes("shock") ||
    q.includes("exam")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "panik-kalm-panik") || MEME_TEMPLATES[3];
  }

  if (
    q.includes("choice") ||
    q.includes("choose") ||
    q.includes("boyfriend") ||
    q.includes("girlfriend") ||
    q.includes("distract") ||
    q.includes("tempt") ||
    q.includes("shiny") ||
    q.includes("cheat") ||
    q.includes("side")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "distracted-bf") || MEME_TEMPLATES[4];
  }

  if (
    q.includes("button") ||
    q.includes("sweat") ||
    q.includes("dilemma") ||
    q.includes("struggle") ||
    q.includes("decision") ||
    q.includes("hard")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "two-buttons") || MEME_TEMPLATES[5];
  }

  if (
    q.includes("drake") ||
    q.includes("like") ||
    q.includes("dislike") ||
    q.includes("prefer") ||
    q.includes("reject") ||
    q.includes("better")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "drake-hotline") || MEME_TEMPLATES[6];
  }

  if (
    q.includes("cat") ||
    q.includes("woman") ||
    q.includes("yell") ||
    q.includes("dinner") ||
    q.includes("salad") ||
    q.includes("argue") ||
    q.includes("fight") ||
    q.includes("blame")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "woman-yelling-cat") || MEME_TEMPLATES[7];
  }

  if (
    q.includes("pikachu") ||
    q.includes("surprise") ||
    q.includes("pokemon") ||
    q.includes("unexpected")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "surprised-pikachu") || MEME_TEMPLATES[8];
  }

  if (
    q.includes("dog") ||
    q.includes("doge") ||
    q.includes("buff") ||
    q.includes("weak") ||
    q.includes("strong") ||
    q.includes("past") ||
    q.includes("now")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "buff-doge") || MEME_TEMPLATES[9];
  }

  if (
    q.includes("girl") ||
    q.includes("evil") ||
    q.includes("ruin") ||
    q.includes("burns") ||
    q.includes("house")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "disaster-girl") || MEME_TEMPLATES[10];
  }

  if (
    q.includes("uno") ||
    q.includes("cards") ||
    q.includes("draw 25") ||
    q.includes("refuse") ||
    q.includes("never")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "uno-draw-25") || MEME_TEMPLATES[11];
  }

  if (
    q.includes("mind") ||
    q.includes("opinion") ||
    q.includes("debate") ||
    q.includes("fact") ||
    q.includes("prove")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "change-my-mind") || MEME_TEMPLATES[12];
  }

  if (
    q.includes("sad") ||
    q.includes("wait") ||
    q.includes("alone") ||
    q.includes("lonely") ||
    q.includes("pablo")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "sad-pablo") || MEME_TEMPLATES[13];
  }

  if (
    q.includes("clown") ||
    q.includes("fool") ||
    q.includes("stupid") ||
    q.includes("mistake") ||
    q.includes("regret")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "clown-makeup") || MEME_TEMPLATES[14];
  }

  if (
    q.includes("fry") ||
    q.includes("not sure") ||
    q.includes("suspicious") ||
    q.includes("squint") ||
    q.includes("doubt")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "futurama-fry") || MEME_TEMPLATES[15];
  }

  if (
    q.includes("smart") ||
    q.includes("brain") ||
    q.includes("think") ||
    q.includes("clever") ||
    q.includes("hack") ||
    q.includes("lifehack")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "roll-safe") || MEME_TEMPLATES[16];
  }

  if (
    q.includes("bernie") ||
    q.includes("asking") ||
    q.includes("again") ||
    q.includes("support")
  ) {
    return MEME_TEMPLATES.find((t) => t.id === "bernie-asking") || MEME_TEMPLATES[17];
  }

  // Keyword match across all templates (including the 100+ dynamic ones)
  const pool = ALL_TEMPLATES.length > 0 ? ALL_TEMPLATES : MEME_TEMPLATES;
  for (const tpl of pool) {
    if (tpl.keywords && tpl.keywords.some((kw: string) => q.includes(kw.toLowerCase()))) {
      return tpl;
    }
  }

  // Name match
  for (const tpl of pool) {
    if (q.includes(tpl.name.toLowerCase())) {
      return tpl;
    }
  }

  let hash = 0;
  for (let i = 0; i < query.length; i++) hash = (hash << 5) - hash + query.charCodeAt(i);
  const idx = Math.abs(hash) % pool.length;
  return pool[idx];
}

// Find 6 other relevant templates matching the theme for alternative choices
function findRelatedTemplates(query: string, excludeId?: string, limit: number = 6) {
  const primary = findMatchingTemplate(query);
  const exclude = excludeId || primary.id;
  const q = (query || "").toLowerCase();
  const words = q.split(/\s+/).filter((w) => w.length > 2);

  const pool = ALL_TEMPLATES.length > 0 ? ALL_TEMPLATES : MEME_TEMPLATES;
  const candidates = pool.filter((t) => t.id !== exclude);
  const scored = candidates.map((t) => {
    let score = 0;
    const nameLower = t.name.toLowerCase();
    for (const w of words) {
      if (nameLower.includes(w)) score += 5;
    }
    for (const kw of t.keywords || []) {
      if (q.includes(kw.toLowerCase())) score += 2;
    }
    return { template: t, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit).map((s) => s.template);
}

// Generate an expressive, standalone vector cartoon illustration using Gemini
async function generateSvgIllustration(prompt: string): Promise<string | null> {
  const gemini = getGeminiClient();
  if (!gemini) return null;

  const sys = `You are an expert comic meme illustrator and vector graphic designer.
Create a complete, colorful, expressive SVG cartoon illustration illustrating this situation: "${prompt}".
Requirements:
1. Return ONLY valid SVG code starting with <svg and ending with </svg>.
2. Explicitly include: viewBox="0 0 800 800" width="800" height="800" xmlns="http://www.w3.org/2000/svg".
3. Vivid colors, dynamic cartoon expressions, recognizable situation, scenery, depth.
4. CRITICAL: Absolutely NO text, letters, or words inside the SVG (user provides meme captions).
5. Leave clear margins at top and bottom for text placement.
Do NOT include markdown formatting (\`\`\`xml or \`\`\`svg), output raw SVG text only.`;

  for (const model of CANDIDATE_GEMINI_MODELS) {
    try {
      const resp = await gemini.models.generateContent({
        model,
        contents: sys,
      });
      if (resp.text) {
        let svg = resp.text.trim();
        svg = svg.replace(/^```(svg|xml)?/gi, "").replace(/```$/gi, "").trim();
        const start = svg.indexOf("<svg");
        const end = svg.lastIndexOf("</svg>");
        if (start !== -1 && end !== -1) {
          svg = svg.slice(start, end + 6);
          if (!svg.includes('xmlns="http://www.w3.org/2000/svg"')) {
            svg = svg.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"');
          }
          if (!svg.includes("width=")) {
            svg = svg.replace("<svg", '<svg width="800" height="800"');
          }
          if (!svg.includes("viewBox=")) {
            svg = svg.replace("<svg", '<svg viewBox="0 0 800 800"');
          }
          return svg;
        }
      }
    } catch (e: any) {
      console.log(`[Info] SVG generation failed with ${model}:`, e?.message?.slice(0, 80));
    }
  }
  return null;
}

// --- AI IMAGE GENERATION ---
// Supports photorealistic, comic, 3D animated, and Gemini vector styles, or iconic templates
app.post("/api/generate-image", async (req: Request, res: Response) => {
  try {
    const { prompt, mode, style = "photo", seed } = req.body || {};
    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "A 'prompt' string is required." });
    }

    const cleanPrompt = prompt.trim();
    const matchedTemplate = findMatchingTemplate(cleanPrompt);
    const relatedTemplates = findRelatedTemplates(cleanPrompt, matchedTemplate.id, 6);

    // If classic template mode requested explicitly
    if (mode === "template") {
      return res.json({
        image: matchedTemplate.url,
        templateName: matchedTemplate.name,
        templateId: matchedTemplate.id,
        matchedTemplate,
        relatedTemplates,
        provider: "classic-template",
      });
    }

    // If SVG vector artwork requested
    if (style === "svg") {
      const svg = await generateSvgIllustration(cleanPrompt);
      if (svg) {
        return res.json({
          image: `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`,
          visualPrompt: cleanPrompt,
          provider: "gemini-svg",
          matchedTemplate,
          relatedTemplates,
        });
      }
    }

    // High quality AI image synthesis with chosen style (photo, comic, 3d)
    const randomSeed = typeof seed === "number" ? seed : Math.floor(Math.random() * 9999999);
    let styleDescriptor = "candid humorous photograph, expressive funny facial expression, crisp lighting, high detail, 4k, uncluttered composition with copy space at top and bottom, strictly NO text, NO letters, NO words";
    if (style === "comic") {
      styleDescriptor = "vibrant comic book meme illustration, dynamic outlines, funny expressive characters, colorful, copy space top and bottom, strictly NO text, NO words";
    } else if (style === "3d") {
      styleDescriptor = "3D Pixar animated character render, funny exaggerated facial expression, volumetric studio lighting, clean background, strictly NO text, NO words";
    }

    const conciseSubject = cleanPrompt
      .replace(/[^\w\s]/gi, " ")
      .replace(/\s+/g, " ")
      .slice(0, 120)
      .trim();

    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
      `${conciseSubject}, ${styleDescriptor}`
    )}?width=800&height=800&nologo=true&seed=${randomSeed}`;

    try {
      const imgFetch = await fetch(pollinationsUrl, { signal: AbortSignal.timeout(8000) });
      if (imgFetch.ok) {
        const arrayBuf = await imgFetch.arrayBuffer();
        const buffer = Buffer.from(arrayBuf);
        const base64 = buffer.toString("base64");
        const contentType = imgFetch.headers.get("content-type") || "image/jpeg";
        return res.json({
          image: `data:${contentType};base64,${base64}`,
          visualPrompt: cleanPrompt,
          provider: `ai-${style}`,
          seed: randomSeed,
          style,
          matchedTemplate,
          relatedTemplates,
        });
      }
    } catch (pollErr) {
      console.log("[Info] Fast template fallback selected for image generation:", cleanPrompt.slice(0, 40));
    }

    // Fallback: Gracefully provide the authentic classic meme template
    return res.json({
      image: matchedTemplate.url,
      visualPrompt: cleanPrompt,
      templateName: matchedTemplate.name,
      templateId: matchedTemplate.id,
      matchedTemplate,
      relatedTemplates,
      provider: "classic-template",
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : "Internal image generation error";
    console.error("Error generating image:", err);
    const fallbackTemplate = findMatchingTemplate(req.body?.prompt || "meme");
    return res.json({
      image: fallbackTemplate.url,
      matchedTemplate: fallbackTemplate,
      provider: "template-fallback",
    });
  }
});

// Start server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
